#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/position.h"
#include "../include/R_x.h"
#include "../include/R_y.h"
#include "../include/R_z.h"
#include "../include/sign.h"
#include "../include/timediff.h"
#include "../include/unit.h"
#include "../include/angl.h"
#include "../include/Legendre.h"
#include "../include/TimeUpdate.h"
#include "../include/PoleMatrix.h"
#include "../include/Mjday.h"
#include "../include/Mjday_TDB.h"
#include "../include/NutMatrix.h"
#include "../include/PrexMatrix.h"
#include "../include/MeasUpdate.h"
#include "../include/MeanObliquity.h"
#include "../include/gmst.h"
#include "../include/Frac.h"
#include "../include/LTC.h"
#include "../include/Geodetic.h"
#include "../include/gibbs.h"
#include "../include/hgibbs.h"
#include "../include/NutAngles.h"
#include "../include/AccelPointMass.h"
#include "../include/EccAnom.h"
#include "../include/EqnEquinox.h"
#include "../include/gast.h"
#include "../include/AzelPa.h"
#include "../include/AccelHarmonic.h"
#include "../include/Cheb3D.h"
#include "../include/globales.h"
#include "../include/GHAmatrix.h"
#include "../include/IERS.h"
#include "../include/GAccelHarmonic.h"
#include "../include/ode.h"
#include "../include/VarEqn.h"


#define FAIL() printf("\nfailure in %s() line %d\n", __func__, __LINE__)
#define _assert(test) do { if (!(test)) { FAIL(); return 1; } } while(0)
#define _verify(test) do { int r=test(); tests_run++; if(r) return r; } while(0)

//Prueba actual  gcc testIOD_KF.c ../src/arrays.c ../src/R_x.c ../src/R_y.c ../src/R_z.c ../src/timediff.c ../src/unit.c ../src/sign.c ../src/position.c ../src/angl.c ../src/Legendre.c ../src/TimeUpdate.c ../src/PoleMatrix.c ../src/Mjday.c ../src/Mjday_TDB.c ../src/PrexMatrix.c ../src/gmst.c ../src/MeanObliquity.c ../src/Frac.c ../src/LTC.c ../src/Geodetic.c ../src/gibbs.c ../src/NutAngles.c ../src/hgibbs.c ../src/AccelPointMass.c ../src/EccAnom.c ../src/EqnEquinox.c ../src/gast.c ../src/AzelPa.c ../src/NutMatrix.c ../src/AccelHarmonic.c ../src/Cheb3D.c ../src/GHAMatrix.c ../src/IERS.c

int tests_run = 0;

int position_01()
{
    double lon, lat, alt, *Rs, *sol;
    
    sol = vector(3);
    lon = -2.76234307910694;
    lat = 0.376551295459273;
    alt = 300.2;
    sol[0] = -5512567.84003607;
    sol[1] = -2196994.44666933;
    sol[2] = 2330804.96614689;
    
    Rs = position(lon, lat, alt);
    
    _assert(compareV(Rs, 3, sol, 3));

    freeVector(Rs, 3);
    freeVector(sol,3);
    
    return 0;
}

int dot_01()
{
    double *v1, *v2, sol;
    
    v1 = vector(3);
    v2 = vector(3);
    
    v1[0] = 1; v1[1] = 2; v1[2] = 3;
    v2[0] = 1; v2[1] = 2; v2[2] = 3;
    sol = 14.0;

    _assert(fabs(sol-dot(v1, 3, v2, 3)) < pow(10, -10));

    freeVector(v1, 3);
    freeVector(v2, 3);

    return 0;
}

int norma_01()
{
    double *w, sol;
    
    w = vector(3);
    w[0] = 2.0; w[1] = 0.0; w[2] = 0.0;
    sol = 2.0;

    _assert(fabs(sol-norma(w, 3)) < pow(10, -10));

    freeVector(w, 3);

    return 0;
}

int trasp_01()
{
    double **m1, **sol, **tr;
    
    sol = array(3, 3);
    m1  = array(3, 3);

    m1[0][0] = 1; m1[0][1] = 0; m1[0][2] = 2;
    m1[1][0] = -1; m1[1][1] = 5; m1[1][2] = 0;
    m1[2][0] = 0; m1[2][1] = 3; m1[2][2] = -9;

    sol[0][0] = 1; sol[0][1] = -1; sol[0][2] = 0;
    sol[1][0] = 0; sol[1][1] = 5; sol[1][2] = 3;
    sol[2][0] = 2; sol[2][1] = 0; sol[2][2] = -9;

    tr = trasp(m1,3);
    
    // printArray(sol,3,3);
    // printArray(tr,3,3);

    _assert(compare(tr, 3, 3, sol, 3, 3));

    freeArray(sol, 3, 3);
    freeArray(tr, 3, 3);
    freeArray(m1, 3, 3);

    return 0;
}

int inv_01()
{
    double **m1, **sol, **in;

    sol = array(3, 3);
    m1  = array(3, 3);

/*
    m1[0][0] = 1; m1[0][1] = 0; m1[0][2] = 2;
    m1[1][0] = -1; m1[1][1] = 5; m1[1][2] = 0;
    m1[2][0] = 0; m1[2][1] = 3; m1[2][2] = -9;
    sol[0][0] = 0.88235294117647; sol[0][1] = -0.11764705882352; sol[0][2] = 0.1960784313725;
    sol[1][0] = 0.17647058823529; sol[1][1] = 0.17647058823529; sol[1][2] = 0.03921568627451;
    sol[2][0] = 0.05882352941176; sol[2][1] = 0.05882352941176; sol[2][2] = -0.09803921568627;
    in = inv(m1, 3);
    printArray(sol,3,3);
    printArray(in,3,3);
*/
    sol = array(3, 3);
    sol[0][0] = 1; sol[1][1] = 1; sol[2][2] = 1;
    m1 = eye(3);
    

    
    in = inv(m1, 3);
    // printArray(sol,3,3);
    //printArray(in,3,3);

    _assert(compare(in, 3, 3, sol, 3, 3));

    freeArray(sol, 3, 3);
    freeArray(in, 3, 3);
    freeArray(m1, 3, 3);

    return 0;
}

int prod_01()
{
    double **m, **m1, **m2, **sol;
    
    sol = array(3, 3);
    m1  = array(3, 3);
    m2  = array(3, 3);
    
    m1[0][0] = 1; m1[0][1] = 2; m1[0][2] = 3;
    m1[1][0] = 4; m1[1][1] = 5; m1[1][2] = 6;
    m1[2][0] = 7; m1[2][1] = 8; m1[2][2] = 9;
    m2[0][0] = 1; m2[0][1] = 2; m2[0][2] = 3;
    m2[1][0] = 4; m2[1][1] = 5; m2[1][2] = 6;
    m2[2][0] = 7; m2[2][1] = 8; m2[2][2] = 9;

    sol[0][0] = 30; sol[0][1] = 36; sol[0][2] = 42;
    sol[1][0] = 66; sol[1][1] = 81; sol[1][2] = 96;
    sol[2][0] = 102; sol[2][1] = 126; sol[2][2] = 150;

    m = prod(m1, 3, 3, m2, 3, 3);
    
    // printf("Producto de matrices: \n");
    // printArray(m, 3, 3);
    // printArray(sol, 3, 3);
    
    _assert(compare(m, 3, 3, sol, 3, 3));

    freeArray(sol, 3, 3);
    freeArray(m, 3, 3);
    freeArray(m1, 3, 3);
    freeArray(m2, 3, 3);
    
    return 0;
}

int eye_01()
{
    double **m, **sol;
    
    sol = array(3, 3);
    sol[0][0] = 1; sol[1][1] = 1; sol[2][2] = 1;
    m = eye(3);
    
    _assert(compare(m, 3, 3, sol, 3, 3));

    freeArray(sol, 3, 3);
    freeArray(m, 3, 3);

    return 0;
}
int sum_01()
{
    double **m, **m1, **m2, **sol;
    
    sol = array(3, 3);
    m1  = array(3, 3);
    m2  = array(3, 3);
    
    m1[0][0] = 1; m1[0][1] = 2; m1[0][2] = 3;
    m1[1][0] = 1; m1[1][1] = 2; m1[1][2] = 3;
    m1[2][0] = 1; m1[2][1] = 2; m1[2][2] = 3;
    m2[0][0] = 1; m2[0][1] = 2; m2[0][2] = 3;
    m2[1][0] = 1; m2[1][1] = 2; m2[1][2] = 3;
    m2[2][0] = 1; m2[2][1] = 2; m2[2][2] = 3;

    sol[0][0] = 2; sol[0][1] = 4; sol[0][2] = 6;
    sol[1][0] = 2; sol[1][1] = 4; sol[1][2] = 6;
    sol[2][0] = 2; sol[2][1] = 4; sol[2][2] = 6;

    m = sum(m1, 3, 3, m2, 3, 3);
    
    _assert(compare(m, 3, 3, sol, 3, 3));

    freeArray(sol, 3, 3);
    freeArray(m, 3, 3);
    freeArray(m1, 3, 3);
    freeArray(m2, 3, 3);
    
    return 0;
}
int R_x01(){
    double **m;
    m=array(3,3);
    m[0][0] =1.0000; 
    m[0][1] = 0  ;
    m[0][2] = 0;
    m[1][0] = 0 ;  
    m[1][1] = -0.801143615546934;
    m[1][2]=  0.598472144103956;
    m[2][0] = 0  ;
    m[2][1] = -0.598472144103956 ;
    m[2][2]  = -0.801143615546934;

    double **rx=R_x(2.5);

    //printArray(rx,3,3);
    //printArray(m,3,3);

    _assert(compare(m, 3, 3, rx, 3, 3));

    freeArray(rx, 3, 3);
    freeArray(m, 3, 3);

    return 0;
}
int R_y01(){
 
    double **m;
    m=array(3,3);
    m[0][0] =-0.801143615546934;
    m[0][1] = 0  ;
    m[0][2] = -0.598472144103956;
    m[1][0] = 0 ;  
    m[1][1] = 1.0000 ;
    m[1][2]=  0;
    m[2][0] = 0.598472144103956;
    m[2][1] = 0;
    m[2][2]  = -0.801143615546934;

    double **ry=R_y(2.5);

    _assert(compare(m, 3, 3, ry, 3, 3));

    freeArray(ry, 3, 3);
    freeArray(m, 3, 3);

    return 0;
}
int R_z01(){
    double **m;
    m=array(3,3);

    m[0][0] =-0.801143615546934  ; 
    m[0][1] = 0.598472144103956 ;
    m[0][2] = 0;
    m[1][0] = -0.598472144103956  ;  
    m[1][1] = -0.801143615546934;
    m[1][2]=  0;
    m[2][0] = 0  ;
    m[2][1] = 0;
    m[2][2]  = 1;

    double **rz=R_z(2.5);

    _assert(compare(m, 3, 3, rz, 3, 3));

    freeArray(rz, 3, 3);
    freeArray(m, 3, 3);

    return 0;
}
int sign_01(){
    
    double res=-2.5;
    _assert(comparenum(res,sign_(2.5,-1)));

    return 0;

}

int timediff_01(){
    
    double UT1_UTC, TAI_UTC, UT1_TAI, UTC_GPS, UT1_GPS, TT_UTC, GPS_UTC;
    UT1_UTC=1;
    TAI_UTC=2;
    timediff(UT1_UTC,TAI_UTC,&UT1_TAI,&UTC_GPS,&UT1_GPS,&TT_UTC,&GPS_UTC);

    _assert(comparenum(UT1_TAI,-1));
    _assert(comparenum(UTC_GPS,17));
    _assert(comparenum(UT1_GPS,18));
    _assert(comparenum(TT_UTC,34.183999999999997));
    _assert(comparenum(GPS_UTC,-17));
    
   return 0;
}

int unit_01(){

    double *sol =vector(3);
    sol[0]=0.267261241912424;     
    sol[1]=0.534522483824849;
    sol[2]=0.801783725737273;

    double *param =vector(3);
    param[0]=1;     
    param[1]=2;
    param[2]=3;

    double * resultado=vector(3);
    resultado=unit(param,3);

    //printVector(resultado,3);

    _assert(compareV(sol,3,resultado,3));

    freeVector(param,3);
    freeVector(sol,3);
    freeVector(resultado,3);

    return 0;
}
int angl_01(){
    double sol=0.225726128552734;

    double *x,*y,angulo;
    x=vector(3);
    y=vector(3);
    for(int i=0;i<3;i++){
        x[i]=i+1;
        y[i]=i+4;
    }
    angulo=angl(x,3,y,3);
    // printf("angulo \n");
    // printf("%5.15lf",angulo);

    _assert(comparenum(angulo,sol));

    freeVector(x,3);
    freeVector(y,3);

    return 0;

    

}
    
int Legendre_01(){
    double **pm;
    pm=array(2,3);

    pm[0][0] =1.000000000000000 ; 
    pm[0][1] = 0;
    pm[0][2] = 0;
    pm[1][0] = 1.580953519847986 ;  
    pm[1][1] = 0.707521001865149;
    pm[1][2]=  0;

    double **dpm;
    dpm=array(2,3);

    dpm[0][0] = 0 ; 
    dpm[0][1] = 0;
    dpm[0][2] = 0;
    dpm[1][0] = 0.707521001865149;  
    dpm[1][1] = -1.580953519847986;
    dpm[1][2]=  0;

    double **sol1,**sol2;
    sol1=array(2,3);
    sol2=array(2,3);

    Legendre(1,2,1.15,sol1,sol2);
    // printf("Esperado \n");
    // printArray(pm,2,3);
    // printf("Recibido \n");
    // printArray(sol1,2,3);

    // printf("Otra \n");
    // printArray(sol2,2,3);

     _assert(compare(sol1,2,3,pm,2,3));
     _assert(compare(sol2,2,3,dpm,2,3));

    freeArray(sol1,2,3);
    freeArray(sol2,2,3);
    freeArray(pm,2,3);
    freeArray(dpm,2,3);

    return 0;

}
int Legendre_02(){
    double **pm;
    pm=array(4,4);

    pm[0][0] = 1;
    pm[0][1] = 0;
    pm[0][2] = 0;
    pm[0][3] = 0;

    pm[1][0] = 1.580953519847986;
    pm[1][1] = 0.707521001865149;
    pm[1][2] = 0;
    pm[1][3] = 0;

    pm[2][0] = 1.676395850894784;
    pm[2][1] = 1.444051933970253;
    pm[2][2] = 0.323126852953330;
    pm[2][3] = 0;

    pm[3][0] = 1.407539493870567;
    pm[3][1] = 2.095133755653409;
    pm[3][2] = 0.780334027580584;
    pm[3][3] = 0.142569016676441;
   


    double **dpm;
    dpm=array(4,4);

    dpm[0][0] = 0;
    dpm[0][1] = 0;
    dpm[0][2] = 0;
    dpm[0][3] = 0;

    dpm[1][0] = 0.707521001865149;
    dpm[1][1] = -1.580953519847986;
    dpm[1][2] = 0;
    dpm[1][3] = 0;

    dpm[2][0] = 2.501171318404576;
    dpm[2][1] = -2.580475934394097;
    dpm[2][2] = -1.444051933970253;
    dpm[2][3] = 0;

    dpm[3][0] =  5.132008644231824;
    dpm[3][1] = -2.213937121354530;
    dpm[3][2] = -3.138086663289914;
    dpm[3][3] = -0.955710098251664;

    double **sol1,**sol2;
    sol1=array(4,4);
    sol2=array(4,4);

    Legendre(3,3,1.15,sol1,sol2);
    // printf("Esperado \n");
    // printArray(pm,4,4);
    // printf("Recibido \n");
    // printArray(sol1,4,4);

    // printf("Otra \n");
    // printArray(sol2,2,3);

    _assert(compare(sol1,4,4,pm,4,4));
    _assert(compare(sol2,4,4,dpm,4,4));

    freeArray(sol1,4,4);
    freeArray(sol2,4,4);
    freeArray(pm,4,4);
    freeArray(dpm,4,4);

    return 0;
}
int timeupdate_01(){
    double **p;
    p=array(3,3);

    p[0][0] = 1;
    p[0][1] = 2;
    p[0][2] = 3;

    p[1][0] = 4;
    p[1][1] = 5;
    p[1][2] = 6;

    p[2][0] = 7;
    p[2][1] = 8;
    p[2][2] = 9;

    double **phi;
    phi=array(3,3);

    phi[0][0] = 2;
    phi[0][1] = 2;
    phi[0][2] = 2;

    phi[1][0] = 3;
    phi[1][1] = 3;
    phi[1][2] = 3;

    phi[2][0] = 5;
    phi[2][1] = 5;
    phi[2][2] = 5;

    double **Qdt;
    Qdt=array(3,3);

    Qdt[0][0] = 8;
    Qdt[0][1] = 4;
    Qdt[0][2] = 8;

    Qdt[1][0] = 9;
    Qdt[1][1] = 4;
    Qdt[1][2] = 9;

    Qdt[2][0] = 0;
    Qdt[2][1] = 5;
    Qdt[2][2] = 0;

    double **sol;
    sol=array(3,3);

    sol[0][0] = 188;
    sol[0][1] = 274;
    sol[0][2] = 458;

    sol[1][0] = 279;
    sol[1][1] = 409;
    sol[1][2] = 684;

    sol[2][0] = 450;
    sol[2][1] = 680;
    sol[2][2] = 1125;

    double **retu=array(3,3);
    retu=TimeUpdate(p,phi,Qdt,3);
    // double **retu=array(2,2);
    // retu=TimeUpdate(p,phi,Qdt);
    //printArray(retu,3,3);
    _assert(compare(retu,3,3,sol,3,3));

    freeArray(sol,3,3);
    freeArray(retu,3,3);
    freeArray(p,3,3);
    freeArray(phi,3,3);
    freeArray(Qdt,3,3);

    return 0;
}
int PoleMat_01(){
    double **retu=array(3,3);
    retu=PoleMatrix(1.23,1.45);

    double **sol;
    sol=array(3,3);

    sol[0][0] = 0.334237727124503;
    sol[0][1] = 0.935620877585049;
    sol[0][2] = 0.113572510730501;

    sol[1][0] = -0;
    sol[1][1] = 0.120502769367367;
    sol[1][2] = -0.992712991037588;

    sol[2][0] = -0.9424888019316970;
    sol[2][1] = 0.331802133811370;
    sol[2][2] = 0.040276571745557;

    _assert(compare(sol,3,3,retu,3,3));

    freeArray(sol,3,3);
    freeArray(retu,3,3);



    return 0;
}

int Mjday_01(){


    double retu= Mjday(10,12,23,4,6,34);
    double sol= -6.749468287731481e05;
    
    _assert(comparenum(retu,sol));

    return 0;
}

int Mjd_TBD_01(){
    double retu=Mjd_TDB(0.00001);

    double sol= 9.986358295412752e-06;

    _assert(comparenum(retu,sol));

    return 0;
}

int PrecMatrix_01(){
    double **sol,**retu;
    sol=array(3,3);
    retu=array(3,3);

    sol[0][0] = 0.999999999999944;
    sol[0][1] = -3.05853652565061e-07;
    sol[0][2] = -1.33100744612231e-07;

    sol[1][0] = 3.05853652565061e-07;
    sol[1][1] = 0.999999999999953;
    sol[1][2] = -2.03546744972902e-14;

    sol[2][0] = 1.33100744612231e-07;
    sol[2][1] = -2.03546744014912e-14 ;
    sol[2][2] = 0.999999999999991;

    retu=PrecMatrix(0,0.5);

    //printArray(retu,3,3);

    _assert(compare(retu,3,3,sol,3,3));

    return 0;
}

int MeanObliquity_01(){
    double retu,sol;
    sol=0.409413067075155;
    retu=MeanObliquity(0.5);

    _assert(comparenum(retu,sol));

    return 0;
}

int gmst_01(){
    double retu,sol;
    sol=3.8427883750413;
    retu=gmst(2.45);

    _assert(comparenum(retu,sol));

    return 0;
}
int frac_01(){
    double retu,sol;

    retu=frac(6.76);
    sol=0.76;

    _assert(comparenum(retu,sol));

    return 0;
}
int Measupdate_01(){
    //[K,x,P] = MeasUpdate([1,2,3],[2,3,4],[4,4,4],[5,5,5],[1,2,3;1,2,3;9,9,9],[4,5,6;6,5,4;4,5,6],3)
}
int LTC_01(){           
    double **sol,**retu;
    //retu=array(3,3);
    sol=array(3,3);
    sol[0][0] = -0.841470984807897;
    sol[0][1] =  0.54030230586814;
    sol[0][2] = 0;

    sol[1][0] = -0.491295496433882;
    sol[1][1] = -0.765147401234293;
    sol[1][2] = -0.416146836547142;

    sol[2][0] = -0.224845095366153;
    sol[2][1] = -0.350175488374015;
    sol[2][2] =  0.909297426825682;

    retu=LTC(1,2);

    _assert(compare(retu,3,3,sol,3,3));

    freeArray(retu,3,3);
    freeArray(sol,3,3);

    return 0;
}

int Geodetic_01(){

    //[lon,lat,h]=Geodetic([1,2,3])
    // USADA PREVIAMENTE [lon,lat,h]=Geodetic([1,2,3])

    double *ent=vector(3);

    ent[0] = 1;
    ent[1] = 2;
    ent[2] = 3;
  
    // ent[0] = 0.1;
    // ent[1] =  0.2;
    // ent[2] = 0.3;

    double lon,lat,h , lonesp,latesp,hesp;

    lonesp=1.107148717794090;
    latesp=1.570744136243924;
    hesp=-6.356748616533795e+06;
    // lonesp=1.10714871779409;
	// latesp=1.57079110741088;
	// hesp=-6356751.31659156;

    Geodetic(ent,&lon,&lat,&h);

    //printf("Lon:%5.15lf,  Lat:%5.15lf,  H:%5.15lf"   ,lon ,lat,h);
    

    _assert(comparenum(lon,lonesp));
    _assert(comparenum(lat,latesp));
    _assert(comparenum(h,hesp));

    return 0;
}
int gibbs_01(){
    double *v2sol,*v2retu;
    double *r1,*r2,*r3;
    r1=vector(3);
    r2=vector(3);
    r3=vector(3);
    v2sol=vector(3);
    v2retu=vector(3);

    r1[0]=1;
    r1[1]=2;
    r1[2]=3;

    r2[0]=3;
    r2[1]=3;
    r2[2]=3;

    r3[0]=5;
    r3[1]=6;
    r3[2]=7;
    
    double theta,theta1,copa;
    char  error[255];
    gibbs(r1,r2,r3,v2retu,&theta,&theta1,&copa,error);

    v2sol[0]=4.120717212149933e06;
    v2sol[1]=5.123868166641572e06;
    v2sol[2]=6.127019121133201e06;
    
    _assert(comparenum(theta,0.387596686655181));
    _assert(comparenum(theta1,0.135251958244656));
    _assert(comparenum(copa,1.387778780781446e-17));
    //printf("%s",error); //Funciona
    //printVector(v2retu,3);  //Mal return de 0.0 0.0 0.0 fallo de memoria ------> ARREGLADO
    _assert(compareV(v2sol,3,v2retu,3));
    
    freeVector(v2retu,3);
    freeVector(v2sol,3);
    freeVector(r1,3);
    freeVector(r2,3);
    freeVector(r3,3);


    return 0;
}

int hgibbs_01(){
    double *v2sol,*v2retu;
    double *r1,*r2,*r3;
    r1=vector(3);
    r2=vector(3);
    r3=vector(3);
    v2sol=vector(3);
    v2retu=vector(3);

    r1[0]=1;
    r1[1]=2;
    r1[2]=3;

    r2[0]=3;
    r2[1]=3;
    r2[2]=3;

    r3[0]=5;
    r3[1]=6;
    r3[2]=7;

    double theta,theta1,copa;
    char  error[255];
    hgibbs(r1,r2,r3,1.25,2.2,3.3,v2retu,&theta,&theta1,&copa,error);

    v2sol[0]=-39244394455173744.00000000000000000000 ;
    v2sol[1]=-97146966662624576.00000000000000000000;
    v2sol[2]=-155049538870075424.00000000000000000000;

    _assert(comparenum(theta,0.387596686655181));
    _assert(comparenum(theta1,0.135251958244656));
    _assert(comparenum(copa,1.387778780781446e-17));
    //printf("%s",error); //Funciona
    //printVector(v2retu,3);  //Mal return de 0.0 0.0 0.0 fallo de memoria ------> ARREGLADO
    //printVector(v2retu,3);
    _assert(compareV(v2sol,3,v2retu,3));

    freeVector(v2retu,3);
    freeVector(v2sol,3);

    freeVector(r1,3);
    freeVector(r2,3);
    freeVector(r3,3);

    return 0;
}

int NutAngles_01(){
    double dpsiesp,depsesp,dpsisal,depssal;
    dpsiesp=2.72161652946617e-05;
    depsesp=3.92714896075712e-05;

    NutAngles(1.76,&dpsisal,&depssal);
    //printf("%5.15lf",dpsisal); //Funciona

    _assert(comparenum(dpsisal,dpsiesp));
    _assert(comparenum(depssal,depsesp));



    return 0;
}

int AccelPointMass_01(){
    double *asol,*aretu;
    double *r1,*r2;
    r1=vector(3);
    r2=vector(3);

    asol=vector(3);
    aretu=vector(3);

    r1[0]=1;
    r1[1]=2;
    r1[2]=3;

    r2[0]=2;
    r2[1]=2;
    r2[2]=2;

    asol[0]=10.455240917144350;
    asol[1]=-1.646891642863408;
    asol[2]= -13.749024202871166;

    aretu=AccelPointMass(r1,3,r2,3,34.23);
    //printVector(aretu,3);

    _assert(compareV(asol,3,aretu,3));

    freeVector(r1,3);
    freeVector(r2,3);
    freeVector(aretu,3);
    freeVector(asol,3);


    return 0;

}

int EccAnom_01(){
    double ret,sol;
    sol=2.821808468878970;
    ret=EccAnom (1.25,5);
    
    _assert(comparenum(sol,ret));

    return 0;
}

int EqnEquinox_01(){
    double ret,sol;
    sol= 2.508757609971055e-05;
    ret=EqnEquinox(1.23);

    _assert(comparenum(ret,sol));

    return 0;
    
}
int gast_01(){
    double ret,sol;
    sol= 3.825610614126119;
    ret=gast(1.45);

    _assert(comparenum(sol,ret));

    return 0;
}

int AzelPa_01(){
     double *dedssol,*deds,*dadssol,*dads,*s;
    double El,Az;
    s=vector(3);
    deds=vector(3);
    dads=vector(3);

    dedssol=vector(3);
    dadssol=vector(3);

    dedssol[0]=-0.095831484749991 ;
    dedssol[1]=-0.191662969499982 ;
    dedssol[2]= 0.159719141249985;

    dadssol[0]= 0.4 ;
    dadssol[1]= -0.2  ;
    dadssol[2]= 0;

    s[0]=1;
    s[1]=2;
    s[2]=3;

    AzElPa(s,&Az,&El,dads,deds);

    // printVector(dads,3);
    // printVector(deds,3);
    
    _assert(comparenum(El,0.930274014115472)) ;   
    _assert(comparenum(Az,0.463647609000806)) ;      
    _assert(compareV(dads,3,dadssol,3));   
    _assert(compareV(deds,3,dedssol,3));      

    freeVector(dads,3);  
    freeVector(deds,3);     
    freeVector(dadssol,3);     
    freeVector(dedssol,3);     
    freeVector(s,3);                                 

    return 0; 

}

int NutMatrix_01(){
    double **sol,**retu;
     sol=array(3,3);
    sol[0][0] = 0.999999999623993   ;
    sol[0][1] = -2.51565103111378e-05 ;
    sol[0][2] = -1.09162543714418e-05;

    sol[1][0] = 2.51560791026998e-05  ;
    sol[1][1] = 0.999999998903467;
    sol[1][2] = -3.9499840995938e-05;

    sol[2][0] =  1.09172480376291e-05 ;
    sol[2][1] =  3.9499566370893e-05 ;
    sol[2][2] =  0.999999999160299;

    retu=NutMatrix(1);

    _assert(compare(sol,3,3,retu,3,3));

    freeArray(retu,3,3);
    freeArray(sol,3,3);

    return 0;
                  
}

int AccelArmonic_01(){
    double **E,*retu,*sol,*r;
    E=array(3,3);
    r=vector(3);
    for (int i = 0; i < 3; i++)
    {
       for (int j = 0; j < 3; j++)
       {
           E[i][j]=(j+1)+(i*3);
       }
       r[i]=i+1;
    }

    //r_bf=mat_x_vec(E,3,3,r,3);

    //printVector(r_bf,3);

    sol=vector(3);

    sol[0]=1.4440444937916e+19;
    sol[1]=1.83972875664309e+19;
    sol[2]=2.23541301949459e+19;

    retu = AccelHarmonic(r,E,3,2,2);

    printf("solucion \n");
    printVector(sol,3);

    printf("retu \n");
    printVector(retu,3);

    
    _assert(compareV(retu,3,sol,3));

    freeArray(E,3,3);
    freeVector(sol,3);
    freeVector(retu,3);
    freeVector(r,3);

    return 0;
}

int Cheb3D_01(){
    double *sol,*retu,*cx,*cy,*cz;

    cx=vector(3);
    cy=vector(3);
    cz=vector(3);
    sol=vector(3);

    sol[0]=2;
    sol[1]=2;
    sol[2]=3;

    for (int i = 0; i < 3; i++)
    {
        cx[i]=i+1;
        cy[i]=2;
        cz[i]=3;
    }
    

    retu=Cheb3D(1,3,1,4,cx,cy,cz);
    //printVector(retu,3);

    _assert(compareV(retu,3,sol,3));

    freeVector(cx,3);
    freeVector(cy,3);
    freeVector(cz,3);
    freeVector(sol,3);
    freeVector(retu,3);



    return 0;
}

int GHAMatrix_01(){
    double **sol,**retu;
    sol=array(3,3);
    retu=array(3,3);

    sol[0][0] = -0.802654688114113   ;
    sol[0][1] = 0.596444005459386 ;
    sol[0][2] = 0;

    sol[1][0] = -0.596444005459386 ;
    sol[1][1] = -0.802654688114113;
    sol[1][2] =  0;

    sol[2][0] =  0 ;
    sol[2][1] =  0 ;
    sol[2][2] =  1;

    retu=GHAmatrix(1.24);

    _assert(compare(sol,3,3,retu,3,3));

    freeArray(retu,3,3);
    freeArray(sol,3,3);


    return 0;
}

int IERS_01(){
    double x_pole,y_pole,UT1_UTC,LOD,dpsi,deps,dx_pole,dy_pole,TAI_UTC;
    IERS(eopdata,49746.1101504629,'l',&x_pole,&y_pole,&UT1_UTC,&LOD,&dpsi,&deps,&dx_pole,&dy_pole,&TAI_UTC);

    //printf("X pole %5.15lf",x_pole);
    _assert(comparenum(x_pole,-5.5938618315225e-07));
    _assert(comparenum(y_pole,2.33554438440328e-06));
    _assert(comparenum(UT1_UTC,0.325764698106663));
    _assert(comparenum(LOD,0.00272668635763566));
    _assert(comparenum(dpsi,-1.16881960640413e-07));
    _assert(comparenum(deps,-2.47881680412601e-08));
    _assert(comparenum(dx_pole,-8.41764150660152e-10));
    _assert(comparenum(dy_pole,-1.56618880119762e-09));
    _assert(comparenum(TAI_UTC,29));

    return 0;
}

int G_AccelHarmonic_01(){
    double **sol,**retu,**E,*r;
    sol=array(3,3);
    retu=array(3,3);

    E=array(3,3);
    r=vector(3);
    for (int i = 0; i < 3; i++)
    {
       for (int j = 0; j < 3; j++)
       {
           E[i][j]=(j+1)+(i*3);
       }
       r[i]=i+1;
    }

    sol[0][0] =  -7.06154395852889e+18      ;
    sol[0][1] = -9.22896090615141e+18  ;
    sol[0][2] =  -1.14734985975622e+19;

    sol[1][0] = -1.14734985975622e+19;
    sol[1][1] = -1.17882195139449e+19;
    sol[1][2] =  -1.45544784312522e+19;

    sol[2][0] =  -1.11679622309615e+19   ;
    sol[2][1] =  -1.43474781217383e+19;
    sol[2][2] =  -1.76354582649423e+19;

    //printf("llega");
    retu=G_AccelHarmonic(r,E,3,2,2);
    //printf("llegapost");
    printArray(retu,3,3);
    _assert(compare(sol,3,3,retu,3,3));

    

    freeArray(E,3,3);
    freeArray(sol,3,3);
    freeArray(retu,3,3);
    freeVector(r,3);

         
    return 0;               
}
int VarEqn_01(){
    double *ent=vector(42);
    ent[0]=7098602.81286994;
    ent[1]=1310605.65207875;
    ent[2]=46418.9107069556;
    ent[3]=613.67000186408;
    ent[4]=-3077.71008494357;
    ent[5]=-6735.86862124388;
    ent[6]=1;
    ent[7]=0;
    ent[8]=0;
    ent[9]=0;
    ent[10]=0;
    ent[11]=0;
    ent[12]=0;
    ent[13]=1;
    ent[14]=0;
    ent[15]=0;
    ent[16]=0;
    ent[17]=0;
    ent[18]=0;
    ent[19]=0;
    ent[20]=1;
    ent[21]=0;
    ent[22]=0;
    ent[23]=0;
    ent[24]=0;
    ent[25]=0;
    ent[26]=0;
    ent[27]=1;
    ent[28]=0;
    ent[29]=0;
    ent[30]=0;
    ent[31]=0;
    ent[32]=0;
    ent[33]=0;
    ent[34]=1;
    ent[35]=0;
    ent[36]=0;
    ent[37]=0;
    ent[38]=0;
    ent[39]=0;
    ent[40]=0;
    ent[41]=1;


    double *retuor=VarEqn(23,ent);

    double *retu=vector(42);
    retu[0]=613.67000186408;
    retu[1]=-3077.71008494357;
    retu[2]=-6735.86862124388;
    retu[3]=-7.53152621196231;
    retu[4]=-1.39056915880885;
    retu[5]=-0.0493777510170146;
    retu[6]=0;
    retu[7]=0;
    retu[8]=0;
    retu[9]=2.01957050194324e-06;
    retu[10]=5.68760756491926e-07;
    retu[11]=2.02201267118785e-08;
    retu[12]=0;
    retu[13]=0;
    retu[14]=0;
    retu[15]=5.68760754937614e-07;
    retu[16]=-9.55990101747517e-07;
    retu[17]=3.73663110869726e-09;
    retu[18]=0;
    retu[19]=0;
    retu[20]=0;
    retu[21]=2.02201277943459e-08;
    retu[22]=3.73663167074767e-09;
    retu[23]=-1.06358040059124e-06;
    retu[24]=1;
    retu[25]=0;
    retu[26]=0;
    retu[27]=0;
    retu[28]=0;
    retu[29]=0;
    retu[30]=0;
    retu[31]=1;
    retu[32]=0;
    retu[33]=0;
    retu[34]=0;
    retu[35]=0;
    retu[36]=0;
    retu[37]=0;
    retu[38]=1;
    retu[39]=0;
    retu[40]=0;
    retu[41]=0;

    _assert(compareV(retuor,42,retu,42));

    freeVector(retu,42);
    freeVector(retuor,42);
    freeVector(retu,42);
    freeVector(retu,42);
 

    return 0;
}
int all_tests()
{
    _verify(position_01);
    _verify(dot_01);
    _verify(norma_01);
    _verify(trasp_01);
    _verify(prod_01);
    _verify(sum_01);
    _verify(eye_01);
    _verify(inv_01);
    _verify(R_x01); 
    _verify(R_y01); 
    //10
    _verify(R_z01); 
    _verify(sign_01);
    _verify(timediff_01);
    _verify(unit_01);
    _verify(angl_01);
    _verify(Legendre_01);
    _verify(Legendre_02);
    _verify(timeupdate_01);
    _verify(Mjday_01);
    _verify(Mjd_TBD_01);
    //20
    _verify(PoleMat_01);
    _verify(PrecMatrix_01);
    _verify(MeanObliquity_01);
    _verify(gmst_01);
    _verify(frac_01);
    _verify(LTC_01);
    _verify(gibbs_01);
    _verify(NutAngles_01);
    _verify(hgibbs_01);
    _verify(AccelPointMass_01);
    //30
    _verify(EccAnom_01);
    _verify(EqnEquinox_01);
    _verify(gast_01);
    _verify(AzelPa_01);
    _verify(NutMatrix_01);
    _verify(Cheb3D_01);
    _verify(GHAMatrix_01);
    _verify(IERS_01);
    _verify(Geodetic_01);  //error a la menos 5 SOLUCIONADO!
    
     //40
   

    //--------------------------FUNCIONAN PERO AMBAS ACABAN CON EL REDONDEO-------------------------
     //_verify(AccelArmonic_01);
    //_verify(G_AccelHarmonic_01);
    //_verify(VarEqn_01);
    
    
   
    return 0;
}
void ode_01 ( void )

/******************************************************************************/
/*
  Purpose:

    TEST01 tests ODE.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    02 February 2012

  Author:

    John Burkardt
*/
{
  double abserr;
  int i;
  int iflag;
  int iwork[5];
  int neqn = 2;
  double relerr;
  int step_num = 12;
  double t;
  double tout;
  double *work;
  double *y;

  printf ( "\n" );
  printf ( "TEST01\n" );
  printf ( "  ODE solves a system of ordinary differential\n" );
  printf ( "  equations.\n" );
  printf ( "\n" );
  printf ( "      T           Y(1)         Y(2)\n" );
  printf ( "\n" );

  abserr = 0.00001;
  relerr = 0.00001;

  iflag = 1;

  t = 0.0;
  y = ( double * ) malloc ( neqn * sizeof ( double ) );
  y[0] = 1.0;
  y[1] = 0.0;

  printf ( "  %8g  %14g  %14g\n", t, y[0], y[1] );

  work = ( double * ) malloc ( ( 100 + 21 * neqn ) * sizeof ( double ) );

  for ( i = 1; i <= step_num; i++ )
  {
    tout = ( double ) ( i ) * 2.0 * pi / ( double ) ( step_num );

    //ode ( f01, neqn, y, &t, tout, relerr, abserr, &iflag, work, iwork );

    if ( iflag != 2 )
    {
      printf ( "\n" );
      printf ( "TEST01 - Fatal error!\n" );
      printf ( "  ODE returned IFLAG = %d\n", iflag );
      break;
    }
    printf ( "  %8g  %14g  %14g\n", t, y[0], y[1] );
  }

  free ( work );
  free ( y );

  return;
}
void ode_02 ( void )

/******************************************************************************/
/*
  Purpose:

    TEST02 tests ODE by integrating in the NEGATIVE time direction.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    02 February 2012

  Author:

    John Burkardt
*/
{
  double abserr;
  int i;
  int iflag;
  int iwork[5];
  int neqn = 2;
  double relerr;
  int step_num = 12;
  double t;
  double tout;
  double *work;
  double *y;

  printf ( "\n" );
  printf ( "TEST02\n" );
  printf ( "  ODE solves a system of ordinary differential\n" );
  printf ( "  equations.\n" );
  printf ( "\n" );
  printf ( "  In this example, we integrate in the negative\n" );
  printf ( "  time direction.\n" );
  printf ( "\n" );
  printf ( "      T           Y(1)         Y(2)\n" );
  printf ( "\n" );

  abserr = 0.00001;
  relerr = 0.00001;

  iflag = 1;

  t = 0.0;
  y = ( double * ) malloc ( neqn * sizeof ( double ) );
  y[0] = 1.0;
  y[1] = 0.0;

  printf ( "  %8g  %14g  %14g\n", t, y[0], y[1] );

  work = ( double * ) malloc ( ( 100 + 21 * neqn ) * sizeof ( double ) );

  for ( i = 1; i <= step_num; i++ )
  {
    tout = - ( double ) ( i ) * 2.0 * pi / ( double ) ( step_num );

    //ode ( f01, neqn, y, &t, tout, relerr, abserr, &iflag, work, iwork );

    if ( iflag != 2 )
    {
      printf ( "\n" );
      printf ( "TEST02 - Fatal error!\n" );
      printf ( "  ODE returned IFLAG = %d\n", iflag );
      break;
    }
    printf ( "  %8g  %14g  %14g\n", t, y[0], y[1] );
  }

  free ( work );
  free ( y );

  return;
}


int main()
{
    extern double **Cnm,**Snm,**eopdata;
    double aux1,aux2;
	FILE *fp;
    int f,c,n,m;

    eopdata=array(13,21413);
    Cnm=array(182,182);
	Snm=array(182,182);

    fp=fopen("../Datos/GGM03S.txt","r");

	if(fp==NULL){
		printf("Fallo al abrir ek fichero GGM03S.txt");
		exit(EXIT_FAILURE);	
	}
	Cnm=array(182,182);
	Snm=array(182,182);
	for(n=0;n<=180;n++){
		for(m=0;m<=n;m++){
		fscanf(fp,"%d%d%lf%lf%lf%lf",&f,&c, &Cnm[n+1][m+1], &Snm[n+1][m+1], &aux1, &aux2);
	    }
	}

    fclose(fp);

    fp=fopen("../Datos/eop19620101.txt","r");
	if(fp==NULL){
		printf("Fallo al abrir el fichero eop19620101.txt");
		exit(EXIT_FAILURE);	
	}

	for(f=0;f<21413;f++){
		fscanf(fp,"%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf",&eopdata[0][f],&eopdata[1][f],&eopdata[2][f],&eopdata[3][f],&eopdata[4][f],&eopdata[5][f],&eopdata[6][f],&eopdata[7][f],&eopdata[8][f],&eopdata[9][f],&eopdata[10][f],&eopdata[11][f],&eopdata[12][f]);
	}

	fclose(fp);


    //printArray(Cnm,182,182);
    //printArray(Snm,182,182);
	
	fclose(fp);

    int result = all_tests();
    
    double *v;
        
    if (result == 0)
        printf("PASSED\n");

    printf("Tests run: %d\n", tests_run);

    return result != 0;
}

void f01 ( double t, double y[], double yp[] )

/******************************************************************************/
/*
  Purpose:

    F01 supplies the right hand side of the ODE for problem 1.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    02 February 2012

  Author:

    John Burkardt

  Parameters:

    Input, double T, the time.

    Input, double Y[], the dependent variable.

    Output, double YP[], the value of the derivative.
*/
{
  yp[0] =   y[1];
  yp[1] = - y[0];

  return;
}

