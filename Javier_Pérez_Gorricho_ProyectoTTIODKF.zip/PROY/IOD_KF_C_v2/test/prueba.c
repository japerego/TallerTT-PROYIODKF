#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include "../include/arrays.h"
#include "../include/globales.h"


//Prueba actual gcc prueba.c ../src/arrays.c ../src/R_y.c
int main()
{

    extern double **eopdata;

    FILE *fp;

    eopdata=array(13,21413);

	fp=fopen("../Datos/eop19620101.txt","r");
	if(fp==NULL){
		printf("Fallo al abrir el fichero eop19620101.txt");
		exit(EXIT_FAILURE);	
	}

	for(int f=0;f<21413;f++){
		fscanf(fp,"%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf",&eopdata[0][f],&eopdata[1][f],&eopdata[2][f],&eopdata[3][f],&eopdata[4][f],&eopdata[5][f],&eopdata[6][f],&eopdata[7][f],&eopdata[8][f],&eopdata[9][f],&eopdata[10][f],&eopdata[11][f],&eopdata[12][f]);
	}

    printArray(eopdata,12,21413);

    return 0;
}