/** @file EccAnom.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the eccentric anomaly for elliptic orbits
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *
 *  @author japerego
 *  @bug No known bugs.
 * 
 */
#ifndef ECCANOM_h_
#define ECCANOM_h_

double EccAnom(double M,double e);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] M Mean anomaly in [rad]
 *  @param [in] e Eccentricity of the orbit [0,1]
 *  @return Eccentric anomaly in [rad].
 */

#endif