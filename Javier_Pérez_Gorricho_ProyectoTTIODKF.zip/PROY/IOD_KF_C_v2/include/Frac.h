/** @file Frac.h
 *  @brief Function prototypes for the code driver.
 *
 *  Fractional part of a number (y=x-[x])
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef FRAC_h_
#define FRAC_h_

double frac(double x);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] x Number input for the obtain of frac number
 *  @return frac of x input
 */

#endif