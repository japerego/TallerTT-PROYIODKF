/** @file MeasUpdate.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the gradient of the Earth's harmonic gravity field 
 * 
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef MEASUPDATE_h_
#define MEASUPDATE_h_

void * MeasUpdate(double * x, double * z, double * g, double *s, double **G, double **P,int  n, double **K);

#endif