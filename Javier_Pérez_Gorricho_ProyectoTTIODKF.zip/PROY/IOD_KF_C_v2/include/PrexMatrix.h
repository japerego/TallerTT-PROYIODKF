/** @file PrexMatrix.h
 *  @brief Function prototypes for the code driver.
 *
 *  Precession transformation of equatorial coordinates
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef PRECMATRIX_h_
#define PRECMATRIX_h_

double **PrecMatrix (double Mjd_1,double Mjd_2);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_1     Epoch given (Modified Julian Date TT)
 *  @param [in] MjD_2     Epoch to precess to (Modified Julian Date TT)
 *  @return PrecMat   Precession transformation matrix
 */

#endif