/** @file AccelPointMass.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the perturbational acceleration due to a point mass
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *
 *  @author japerego
 *  @bug No known bugs.
 * 
 */

#ifndef ACCELPOINTMASS_h_
#define ACCELPOINTMASS_h_

double * AccelPointMass(double * r,int nr, double *s, int ns, double GM);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] r Satellite position vector in the inertial system 
 *  @param [in] s vector
 *  @param [in] nr r dimension
 *  @param [in] ns s dimension
 *  @param [in] GM
 *  @return AccelPointMass vector.
 */
#endif