/** @file globales.h
 *  @brief Function prototypes for the code driver.
 *
 *  Represents types of params Used in some classes.
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
s
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef GLOBALES_h_
#define GLOBALES_h_

typedef struct{
	double Mjd_UTC,Mjd_TT;
	int n,m,sun,moon,planets;
} Param;

double **PC, **Cnm, **Snm, **eopdata;
int n_eqn;
Param AuxParam;


#endif