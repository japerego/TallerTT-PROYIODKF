/** @file Legendre.h
 *  @brief Function prototypes for the code driver.
 *
 *  This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef LEGENDRE_h_
#define LEGENDRE_h_

void Legendre(int n, int m, double fi, double **pnm, double **dpnm);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] n   Used for matrix return dimension rows +1
 *  @param [in] m     Used for matrix return dimension col +1
 *  @param [in] fi    
 *  @param [out] pnm   Matrix output
 *  @param [out] dpnm   Matrix output
 */

#endif
