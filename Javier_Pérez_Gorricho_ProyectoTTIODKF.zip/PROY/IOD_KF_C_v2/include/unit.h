/** @file unit.h
 *  @brief Function prototypes for the code driver.
 *
 *  this function calculates a unit vector given the original vector. if a zero vector is input, the vector is set to zero.
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef UNIT_h_
#define UNIT_h_

double *unit (double *vec, int n);
  /** @brief …
 *
 *  Comments.
 *
 *  @param [in] vec vector
 *  @param [in] n dimension of vec
 *  @return   unit vector
 */



#endif