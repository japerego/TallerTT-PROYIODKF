/** @file VarEqn.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the variational equations, i.e. the derivative of the state vector and the state transition matrix
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef VAREQN_h_
#define VAREQN_h_

double * VarEqn(double x, double *yPhi);
  /** @brief …
 *
 *  Comments.
 *
 *  @param [in] x           Time since epoch in [s]
 *  @param [in] yPhi        (6+36)-dim vector comprising the state vector (y) and the state transition matrix (Phi) in column wise storage order    
 *  @return  yPhip
 */


#endif