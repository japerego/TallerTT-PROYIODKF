/** @file MeanObliquity.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the mean obliquity of the ecliptic
 * 
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef MEANOBLIQUITY_h_
#define MEANOBLIQUITY_h_

double MeanObliquity(double Mdj_TT);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_TT  Modified Julian Date (Terrestrial Time)
 *  @return  Mean obliquity of the ecliptic [rad]
 */


#endif