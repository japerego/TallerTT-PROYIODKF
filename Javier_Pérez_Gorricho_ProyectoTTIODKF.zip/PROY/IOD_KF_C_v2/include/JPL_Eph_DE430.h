/** @file JPL_Eph_DE430.h
 *  @brief Function prototypes for the code driver.
 *
 *  JPL_Eph_DE430: Computes the sun, moon, and nine major planets' equatorial position using JPL Ephemerides

 
 *This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef JPL_EPH_DE430_h_
#define JPL_EPH_DE430_h_

void JPL_Eph_DE430(double * r_Mercury,double * r_Venus,double * r_Earth,double * r_Mars,double * r_Jupiter,double * r_Saturn,double * r_Uranus, double * r_Neptune,double * r_Pluto,double * r_Moon,double * r_Sun, double Mjd_TDB);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_TDB         Modified julian date of TDB   
 *  @param [out] r_Mercury     
 *  @param [out] r_Venus    
 *  @param [out] r_Earth   solar system barycenter (SSB)
 *  @param [out] r_Mars   
 *  @param [out] r_Jupiter  
 *  @param [out] r_Saturn       
 *  @param [out] r_Uranus    
 *  @param [out] r_Neptune    
 *  @param [out] r_Pluto     
 *  @param [out] r_Moon    
 *  @param [out] r_Sun   geocentric equatorial position ([m]  
 */
#endif