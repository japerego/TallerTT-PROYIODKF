/** @file EqnEquinox.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computation of the equation of the equinoxes
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef EQNEQUINOX_h_
#define EQNEQUINOX_h_

double EqnEquinox (double Mjd_TT);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_TT Modified Julian Date (Terrestrial Time)
 *  @return Equation of the equinoxes
 */

#endif