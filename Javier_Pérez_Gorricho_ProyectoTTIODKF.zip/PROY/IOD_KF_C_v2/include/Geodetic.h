/** @file Geodetic.h
 *  @brief Function prototypes for the code driver.
 *
 *  geodetic coordinates (Longitude [rad], latitude [rad], altitude [m])   from given position vector (r [m])
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef GEODETIC_H_
#define GEODETIC_H_


void Geodetic(double * r,double * lon,double * lat,double * h);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] r position vector
 *  @param [out] lon longitude
 *  @param [out] lat latitude
 *  @param [out] h altitude
 */


#endif