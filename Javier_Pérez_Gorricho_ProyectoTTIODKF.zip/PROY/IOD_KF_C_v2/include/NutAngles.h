/** @file NutAngles.h
 *  @brief Function prototypes for the code driver.
 *
 *  Nutation in longitude and obliquity
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef NUTANGLES_h_
#define NUTANGLES_h_

void NutAngles(double Mjd_TT,double  * dpsi,double  * deps);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_TT     Modified Julian Date (Terrestrial Time)       
 *  @param [out] dpsi       Nutation Angles
 *  @param [out] deps       Nutation Angles
 */

#endif