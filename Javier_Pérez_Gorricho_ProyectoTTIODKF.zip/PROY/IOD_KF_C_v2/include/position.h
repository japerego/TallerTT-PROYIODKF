/** @file position.h
 *  @brief Function prototypes for the code driver.
 *
 *  Position vector (r [m]) from geodetic coordinates (Longitude [rad],latitude [rad], altitude [m])
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef POSITION_h_
#define POSITION_h_

double *position(double lon, double lat, double h);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] lon   longitude
 *  @param [in] lat   latitude
 *  @param [in] h   altitude
 *  @param [in] r  Position vector
 *  @return Pole matrix
 */

#endif
