/** @file Mjd_TDB.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the Modified Julian Date for barycentric dynamical time
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef MJDAY_TDB_h_
#define MJDAY_TDB_h_

double Mjd_TDB(double Mjd_TT);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_TT  Modified Julian Date (Terrestrial Time)
 *  @return  - Modified julian date (TDB)
 */

#endif