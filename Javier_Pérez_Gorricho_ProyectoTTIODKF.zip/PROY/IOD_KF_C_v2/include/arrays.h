#ifndef ARRAYS_h_
#define ARRAYS_h_

// vectores

double norma(double *v, int n);
double dot(double *v1, int n1, double *v2, int n2);
double *vector(int n);
void freeVector(double *v, int n);
void printVector(double *v, int n);
int find1(double * v1,int n1, double *v2, int n2,double JD);



// matrices

double **zeros(int nf,int nc);
double **trasp(double **m, int n);
double **inv(double **m, int n);
double **prod(double **mat1, int nf1, int nc1,double **mat2, int nf2, int nc2);
double **eye(int n);
double **sum(double **mat1, int nf1, int nc1, double **mat2, int nf2, int nc2);
int compareV(double *v1, int n1, double *v2, int n2);
int compare(double **mat1, int nf1, int nc1,double **mat2, int nf2, int nc2);
int comparenum( double a, double b);            
double **array(int nf, int nc);
void freeArray(double **mat, int nf, int nc);
void printArray(double **mat, int nf, int nc);


//operaciones

double *mat_x_vec(double **M,int mf,int mc ,double* v,int vn );
double *esc_x_vec(double es,double* v,int vn );
double **mat_x_esc(double **M,int mf,int mc, double es );
double	*sumaVectores(double *v1,double *v2, int n);
double	*restaVectores(double *v1,double *v2, int n);
double **sumaMatrices(double **M,int mf,int mc, double **M2,int mf2,int mc2 );
double * cross(double * v1,int n1, double *v2,int n2);
int findSOLO(double * v1,int n1,double JD);

#endif
