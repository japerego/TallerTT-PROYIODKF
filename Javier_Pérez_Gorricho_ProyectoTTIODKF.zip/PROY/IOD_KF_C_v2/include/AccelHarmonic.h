/** @file AccelHarmonic.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the perturbational acceleration due to a point mass
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.


 *
 *  @author japerego
 *  @bug No known bugs.
 */

#ifndef ACCELHARMONIC_h_
#define ACCELHARMONIC_h_

double * AccelHarmonic (double * r, double **E, int nE, int n_max, int m_max);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] r Satellite position vector in the inertial system 
 *  @param [in] E Transformation matrix to body-fixed system
 *  @param [in] nE E dimension
 *  @param [in] n_max Maximum degree
 *  @param [in] m_max Maximum order (m_max<=n_max; m_max=0 for zonals, only)
 *  @return Acceleration (a=d^2r/dt^2) vector
 */


#endif