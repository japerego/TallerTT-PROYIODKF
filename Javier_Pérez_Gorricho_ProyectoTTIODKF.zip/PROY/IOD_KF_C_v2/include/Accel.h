/** @file Accel.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the acceleration of an Earth orbiting satellite due to 
     - the Earth's harmonic gravity field, 
     - the gravitational perturbations of the Sun and Moon
     - the solar radiation pressure and
     - the atmospheric drag

 *  This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef ACCEL_h_
#define ACCEL_h_

double * Accel(double x, double y);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] x      Terrestrial Time (Modified Julian Date)
 *  @param [in] Y           Satellite state vector in the ICRF/EME2000 system
 *  @return Acceleration (a=d^2r/dt^2) in the ICRF/EME2000 system
 */

#endif