/** @file AzelPa.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes azimuth, elevation and partials from local tangent coordinates
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *
 *  @author japerego
 *  @bug No known bugs.
 * 
 */

#ifndef AZEL_h_
#define AZEL_h_

void AzElPa(double *s, double *Az, double *El, double *dAds, double *dEds);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] s Topocentric local tangent coordinates (East-North-Zenith frame)
 *  @param [out] Az Azimuth [rad]
 *  @param [out] El Elevation [rad]
 *  @param [out] dAds Partials of azimuth w.r.t. s
 *  @param [out] dEds  Partials of elevation w.r.t. s
 */

#endif