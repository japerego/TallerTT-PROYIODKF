/** @file timediff.h
 *  @brief Function prototypes for the code driver.
 *
 *  Time differences [s]
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef TIMEDIFF_h_
#define TIMEDIFF_h_

void timediff(double UT1_UTC,double TAI_UTC, double *UT1_TAI,double *UTC_GPS,double *UT1_GPS, double *TT_UTC, double *GPS_UTC);
  /** @brief …
 *
 *  Comments.
 *
 *  @param [in] UT1_UTC Time differences [s]
 *  @param [in] TAI_UTC  Time differences [s]
 *  @param [out] UT1_TAI Time differences [s]
 *  @param [out] UTC_GPS Time differences [s]
 *  @param [out] UT1_GPS Time differences [s]
 *  @param [out] TT_UTC Time differences [s]
 *  @param [out] GPS_UTC Time differences [s]
 */

#endif