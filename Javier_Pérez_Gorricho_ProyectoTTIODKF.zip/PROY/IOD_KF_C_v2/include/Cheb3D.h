/** @file Cheb3D.h
 *  @brief Function prototypes for the code driver.
 *
 *  Chebyshev approximation of 3-dimensional vectors
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *
 *  @author japerego
 *  @bug No known bugs.
 * 
 */
#ifndef CHEB3D_h_
#define CHEB3D_h_

double * Cheb3D(double t,double N,double  Ta, double Tb, double *Cx, double *Cy,double *Cz);

/** @brief …
 *
 *  Comments.
 *
 *  @param [in] N Topocentric local tangent coordinates (East-North-Zenith frame)
 *  @param [in] Ta Begin interval
 *  @param [in] Tb End interval
 *  @param [in] Cx Coefficients of Chebyshev polyomial (x-coordinate)
 *  @param [in] Cy Coefficients of Chebyshev polyomial (y-coordinate)
 *  @param [in] Cz Coefficients of Chebyshev polyomial (z-coordinate)
 *  @return angle between the two vectors  -pi to pi.
 */
#endif