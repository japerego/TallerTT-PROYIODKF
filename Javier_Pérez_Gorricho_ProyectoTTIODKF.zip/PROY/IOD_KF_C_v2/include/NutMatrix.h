/** @file NutMatrix.h
 *  @brief Function prototypes for the code driver.
 *
 *  Transformation from mean to true equator and equinox
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef NUTMATRIX_h_
#define NUTMATRIX_h_

double **NutMatrix (double Mjd_TT);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_TT     Modified Julian Date (Terrestrial Time)       
 *  @return  NutMat    Nutation matrix
 */

#endif