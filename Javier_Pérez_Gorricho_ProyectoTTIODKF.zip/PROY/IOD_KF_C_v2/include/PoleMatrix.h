/** @file PoleMatrix.h
 *  @brief Function prototypes for the code driver.
 *
 *  Transformation from pseudo Earth-fixed to Earth-fixed coordinates for a given date
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef POLEMATRIX_h_
#define POLEMATRIX_h_

double **  PoleMatrix (double xp,double yp);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] xp    Pole coordinte(xp,yp)
 *  @param [in] yp    Pole coordinte(xp,yp)  
 *  @return Pole matrix
 */

#endif