/** @file GAccelHarmonic.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the gradient of the Earth's harmonic gravity field 
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef G_ACCELHARMONIC_h_
#define G_ACCELHARMONIC_h_

double ** G_AccelHarmonic( double *r, double ** U,int nU, int n_max,int m_max );
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] r  Satellite position vector in the true-of-date system
 *  @param [in] U Transformation matrix to body-fixed system
 *  @param [in] nU u dimension
 *  @param [in] n Gravity model degree
 *  @param [in] m Gravity model order
 *  @return Gradient (G=da/dr) in the true-of-date system
 */

#endif