/** @file Mjday.h
 *  @brief Function prototypes for the code driver.
 *
 *  This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef MJDAY_h_
#define MJDAY_h_

double Mjday(double yr, double mon, double day, double hr, double min, double sec);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] year        - year       
 *  @param [in] mon         - month    
 *  @param [in] day         - day      
 *  @param [in] hr          - universal time hour   
 *  @param [in] min         - universal time min   
 *  @param [in] sec         - universal time sec  
 *  @return  Modified julian date 
 */
#endif