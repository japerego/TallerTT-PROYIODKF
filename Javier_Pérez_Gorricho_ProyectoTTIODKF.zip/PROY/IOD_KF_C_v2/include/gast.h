/** @file gast.h
 *  @brief Function prototypes for the code driver.
 *
 *  Greenwich Apparent Sidereal Time
 * 
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef GAST_h_
#define GAST_h_

double gast(double Mjd_UT1);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_UT1 Modified Julian Date UT1
 *  @return GAST in [rad]
 */

#endif