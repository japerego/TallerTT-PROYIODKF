/** @file gmst.h
 *  @brief Function prototypes for the code driver.
 *
 *  Greenwich Mean Sidereal Time
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef GMST_h_
#define GMST_h_

double gmst(double Mjd_UT1);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_UT1   Modified Julian Date UT1
 *  @return GMST in [rad]
 */

#endif