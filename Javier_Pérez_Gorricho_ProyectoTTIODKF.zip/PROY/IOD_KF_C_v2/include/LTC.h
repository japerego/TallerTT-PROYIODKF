/** @file LTC.h
 *  @brief Function prototypes for the code driver.
 *
 *  Transformation from Greenwich meridian system to local tangent coordinates
 * 
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef LTC_h_
#define LTC_h_

double **LTC(double lon, double lat);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] lon   -Geodetic East longitude [rad]
 *  @param [in] lat    -Geodetic latitude [rad]
 *  @return  -Rotation matrix from the Earth equator and Greenwich meridian
 *           to the local tangent (East-North-Zenith) coordinate system
 */

#endif