
/** @file IERS.h
 *  @brief Function prototypes for the code driver.
 *
 *  Computes the gradient of the Earth's harmonic gravity field 
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef IERS_h_
#define IERS_h_

void IERS(double ** eop,double Mjd_UTC,char interp,double *x_pole,double  *y_pole,double  *UT1_UTC,double  *LOD,double *dpsi,double *deps,double *dx_pole,double *dy_pole,double *TAI_UTC );
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] eop   eopdata data from eop19620101
 *  @param [in] Mjd_UTC - Modified julian date   
 *  @param [in] interp char that selects type of operation        
 *  @param [out] x_pole        Pole coordinate [rad
 *  @param [out] y_pole     Pole coordinate [rad
 *  @param [out] UT1_UTC    UT1-UTC time difference [s]
 *  @param [out] LOD    Length of day [s]
 *  @param [out] dpsi       - angl between vectors           rad
 *  @param [out] deps       - flag indicating success   
 *  @param [out] dx_pole    Pole coordinate [rad]  
 *  @param [out] dy_pole    Pole coordinate [rad]
 *  @param [out] TAI_UTC     TAI-UTC time difference [s]
 */
#endif