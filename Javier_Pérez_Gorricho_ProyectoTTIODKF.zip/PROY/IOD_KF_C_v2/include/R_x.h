/** @file R_x.h
 *  @brief Function prototypes for the code driver.
 *
 *  Returns rot matrix in x
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef R_X_h_
#define R_X_h_

 double ** R_x(double angle);
 /** @brief …
 *
 *  Comments.
 *
 *  @param [in] angle       - angle of rotation [rad]
 *  @return rotmat      - vector result
 */
#endif


