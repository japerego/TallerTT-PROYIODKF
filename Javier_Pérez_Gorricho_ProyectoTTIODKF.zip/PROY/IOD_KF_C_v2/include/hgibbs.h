/** @file hgibbs.h
 *  @brief Function prototypes for the code driver.
 *
 * this function implements the herrick-gibbs approximation for orbit determination, and finds the middle velocity vector for the 3 given position vectors.
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef HGIBBS_h_
#define HGIBBS_h_

void hgibbs(double * r1,double * r2,double * r3,double Mjd1,double Mjd2,double Mjd3,double * v2,double *theta,double * theta1,double * copa, char error[255]);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_UT1   Modified Julian Date UT1
 *  @param [in] r1 - ijk position vector #1         
 *  @param [in] r2  - ijk position vector #2         
 *  @param [in] r3  - ijk position vector #3
 *  @param [in] Mjd1        - julian date of 1st sighting    days from 4713 bc
 *  @param [in] Mjd2        - julian date of 2nd sighting    days from 4713 bc
 *  @param [in] Mjd3        - julian date of 3rd sighting
 *  @param [out] v2          - ijk velocity vector for r2     m/s
 *  @param [out] theta       - angl between vectors           rad
 *  @param [out] error       - flag indicating success   
 *  @param [out] copa       - flag indicating success   
 */
#endif