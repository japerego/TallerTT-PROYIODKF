/** @file GHAMatrix.h
 *  @brief Function prototypes for the code driver.
 *
 *  Transformation from true equator and equinox to Earth equator and    Greenwich meridian system 
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef GHAMATRIX_h_
#define GHAMATRIX_h_

double ** GHAmatrix(double Mjd_UT1);
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] Mjd_UT1   Modified Julian Date UT1
 *  @return GHAmat Greenwich Hour Angle matrix
 */

#endif