/** @file R_z.h
 *  @brief Function prototypes for the code driver.
 *
 *   Returns rot matrix in z
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef R_Z_h_
#define R_Z_h_

 double ** R_z(double angle);
  /** @brief …
 *
 *  Comments.
 *
 *  @param [in] angle       - angle of rotation [rad]
 *  @return rotmat      - vector result
 */
#endif
