/** @file sign.h
 *  @brief Function prototypes for the code driver.
 *
 *  returns absolute value of a with sign of b
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
#ifndef SIGN_h_
#define SIGN_h_

double sign_(double a,double b);
  /** @brief …
 *
 *  Comments.
 *
 *  @param [in] a  value of return
 *  @param [in] b  sign of return
 *  @return value of a with sign of b
 */

#endif