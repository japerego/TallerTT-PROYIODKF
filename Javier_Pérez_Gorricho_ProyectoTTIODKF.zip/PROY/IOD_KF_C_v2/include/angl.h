/** @file angl.h
 *  @brief Function prototypes for the code driver.
 *
 *  Returns the angle between 2 vectors
 * 
 * This contains the prototypes for the code
 *  driver and eventually any macros, constants,
 *  or global variables you will need.

 *
 *  @author japerego
 *  @bug No known bugs.
 * 
 */

#ifndef ANGL_h_
#define ANGL_h_

double angl( double * vec1,int n1,double *vec2,int n2 );
/** @brief …
 *
 *  Comments.
 *
 *  @param [in] vec1 vector 1
 *  @param [in] vec2 vector 2
 *  @param [in] n1 vec1 dimension
 *  @param [in] n2 vec2 dimension
 *  @return angle between the two vectors  -pi to pi.
 */

#endif