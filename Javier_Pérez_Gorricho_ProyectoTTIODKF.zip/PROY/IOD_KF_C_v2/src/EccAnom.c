/*--------------------------------------------------------------------------
%
% Purpose:
%   Computes the eccentric anomaly for elliptic orbits
%
% Inputs:
%   M         Mean anomaly in [rad]
%   e         Eccentricity of the orbit [0,1]
% 
% Output:
%             Eccentric anomaly in [rad]
%
% Last modified:   2015/08/12   M. Mahooti
% 
%--------------------------------------------------------------------------
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
/** @file EccAnom.c
 *  @brief A code driver.
 *
 *  Computes the eccentric anomaly for elliptic orbits
 *
 *  @author japerego
 *  @bug No known bugs.
 */
double EccAnom(double M,double e){
	int maxit = 15;
	int i = 1;

	double E;
	//DUDA
	M = fmod(M,(2.0*pi));
	
	if (e<0.8){ E = M; }
	else{E = pi;}

	double f = E - e*sin(E) - M;
	E = E - f / ( 1.0 - e*cos(E) );
	
	while (fabs(f) > 1e2*2.22044604925031e-16)  {
		f = E - e*sin(E) - M;
    		E = E - f / ( 1.0 - e*cos(E) );
    		i = i+1;
    		if (i==maxit){
    			printf("convergence problems in EccAnom");
    			exit(EXIT_FAILURE);	
    		}
	}  
    		
    	
}



