
//--------------------------------------------------------------------------
//
// AccelPointMass: Computes the perturbational acceleration due to a point
//				  mass
//
// Inputs:
//   r           Satellite position vector 
//   s           Point mass position vector
//   GM          Gravitational coefficient of point mass
//
// Output:
//   a    		Acceleration (a=d^2r/dt^2)
//
// Last modified:   2018/01/27   M. Mahooti
//
//--------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include "../include/arrays.h"
/** @file AccelPointMass.c
 *  @brief A code driver.
 *
 *  Computes the perturbational acceleration due to a point mass
 *
 *  @author japerego
 *  @bug No known bugs.
 */
double * AccelPointMass(double * r,int nr, double *s, int ns, double GM){
	double *d,*a;
	d = sumaVectores(r,esc_x_vec(-1.0,s,ns),nr);
	a = sumaVectores( esc_x_vec(-GM/pow(norma(d,3),3),d,ns),esc_x_vec(-GM/pow(norma(s,3),3),s,ns),ns);
	
	freeVector(d,3);
	
	return a;

	
}



