#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
/** @file unit.c
 *  @brief A code driver.
 *
 *  this function calculates a unit vector given the original vector. if a zero vector is input, the vector is set to zero.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double *unit (double *vec, int n){
	double small;
	double *aux=vector(3);
	small=0.000001;

	double normae=norma(vec,n);
	
	if(normae>small){
		for(int i=0;i<n;++i){
			aux[i]=vec[i]/normae;
		}
	}
	else{
		for(int i=0;i<n;++i){
			aux[i]=0.0;
		}
	}

	return aux;
	
	
}
