#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/NutAngles.h"
#include "../include/MeanObliquity.h"
/** @file EqnEquinox.c
 *  @brief A code driver.
 *
 *  Computation of the equation of the equinoxes
 *
 *  @author japerego
 *  @bug No known bugs.
 */
double EqnEquinox (double Mjd_TT){
	double dpsi, deps;
	NutAngles(Mjd_TT,&dpsi,&deps);

// Equation of the equinoxes
	double EqE = dpsi * cos( MeanObliquity(Mjd_TT) );
	
	return EqE;
}

//Nutation in longitude and obliquity

