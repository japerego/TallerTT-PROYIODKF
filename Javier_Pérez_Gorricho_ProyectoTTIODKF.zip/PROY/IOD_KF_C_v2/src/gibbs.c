#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include <string.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/unit.h"
#include "../include/iodkf.h"
#include "../include/angl.h"
/** @file gibbs.c
 *  @brief A code driver.
 *
 *  this function performs the gibbs method of orbit determination. thismethod determines the velocity at the middle point of the 3 given position vectors.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
void gibbs(double * r1,double * r2,double * r3, double * v2,double *theta,double * theta1,double * copa, char error[255]){
	
	double magr1,magr2,magr3,small;
	double *p,*q,*w,*pn,*r1n;
	
	small= 0.00000001;
	*theta = 0.0;
	*theta1= 0.0;
	strcpy(error,"ok");
	magr1 = norma( r1 ,3);
	magr2 = norma( r2 ,3);
	magr3 = norma( r3 ,3);
	for (int i=0; i<3;++i){
		v2[i]=0.0;
	}
	p=cross(r2,3,r3,3);
	q = cross( r3,3,r1,3 );
	w = cross( r1,3,r2,3 );

	pn = unit( p ,3);
	r1n = unit( r1 ,3);
	*copa=  asin( dot( pn,3,r1n,3 ));

	if ( abs( dot(r1n,3,pn,3) ) > 0.017452406 ) {
		strcpy(error,"not coplanar");
	} 

	double *d, magd, *n,magn,*nn,*dn;
	d = sumaVectores(sumaVectores(p,q,3),w,3);
	magd = norma(d,3);
	n = sumaVectores(sumaVectores(esc_x_vec(magr1,p,3),esc_x_vec(magr2,q,3),3),esc_x_vec(magr3,w,3),3);
	magn = norma(n,3);
	nn = unit( n ,3);
	dn = unit( d ,3);

	if ( ( abs(magd)<small ) || ( abs(magn)<small ) || ( dot(nn,3,dn,3) < small ) ){
		strcpy(error,"impossible");

	} 
    else{
		*theta  = angl( r1,3,r2,3 );
    	*theta1 = angl( r2,3,r3,3 );
		double r1mr2,r3mr1,r2mr3,l,tover2;
		double *sw,*b,*s;
		//----------- perform gibbs method to find v2 -----------
      	r1mr2 = magr1-magr2;
     	r3mr1 = magr3-magr1;
      	r2mr3 = magr2-magr3;
		//printf("%5.15lf \n",r1mr2);
      	s  =sumaVectores(sumaVectores(esc_x_vec(r1mr2,r3,3),esc_x_vec(r3mr1,r2,3),3),esc_x_vec(r2mr3,r1,3),3); //MAL
      	b  = cross( d,3,r2,3 ); //BIEN
      	l  = sqrt(GM_Earth / (magd*magn) ); //BIEN
      	tover2= l / magr2; //BIEN

		//printf("%5.15lf \n",tover2);
		//printVector(b,3);
		//printf("l = %5.15lf \n",l);
		double *aux;
      	aux = sumaVectores( esc_x_vec(tover2, b,3) , esc_x_vec(l, s,3),3);
		//printVector(aux,3);

		for(int i=0;i<3;i++){
			v2[i]=aux[i];
		}

		freeVector(d,3);
		freeVector(s,3);
		freeVector(aux,3);
		freeVector(nn,3);
		freeVector(dn,3);
		freeVector(b,3);
		freeVector(n,3);
		freeVector(r1n,3);
		freeVector(p,3);
		freeVector(q,3);
		freeVector(w,3);

  }

}
