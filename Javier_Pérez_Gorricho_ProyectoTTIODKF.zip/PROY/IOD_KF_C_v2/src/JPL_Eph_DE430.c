
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/GHAmatrix.h"
#include "../include/Cheb3D.h"
void JPL_Eph_DE430(double * r_Mercury,double * r_Venus,double * r_Earth,double * r_Mars,double * r_Jupiter,double * r_Saturn,double * r_Uranus,
          double * r_Neptune,double * r_Pluto,double * r_Moon,double * r_Sun) 
{
	extern double  **PC;
	double *v1,*v2,jd,dt, *PCtemp,*Cx_Earth,*Cy_Earth,*Cz_Earth,*Cx,*Cy,*Cz,JD,Mjd_TDB,Mjd0;
	int i,j,t1,temp[4];

	r_Earth = vector(3);
	r_Mercury = vector(3);
	r_Venus = vector(3);
	r_Mars = vector(3);
	r_Jupiter = vector(3);
	r_Saturn = vector(3);
	r_Uranus = vector(3);
	r_Neptune = vector(3);
	r_Pluto = vector(3);
	r_Sun = vector(3);
	
	JD = Mjd_TDB + 2400000.5;
	
	v1= vector(2285);
	v2= vector(2285);

	for(int j=0;j<2285;++j){
		v1[j]=PC[j][0];
		v2[j]=PC[j][0];
	}
	
	i= find1(v1,2285,v2,2285,JD);
	
	freeVector(v1,2285);
	freeVector(v2,2285);
	
	PCtemp= vector(1020);
	
	for(int j=0;j<1020;++j){
		PCtemp[j]=PC[i][j];
	
	}
	t1=PCtemp[0] -2400000.5;
	dt=Mjd_TDB -t1;
	
	
	for(j=0;j<4;++j){
		temp[j]=231+ 13*j;
	}
	
	Cx_Earth =vector(26);
	Cy_Earth =vector(26);
	Cz_Earth =vector(26);
	
	for(j=0;j<13;++j){
		Cx_Earth[j]=PCtemp[temp[0]+ j -1];
		Cy_Earth[j]=PCtemp[temp[1]+ j -1];
		Cz_Earth[j]=PCtemp[temp[2]+ j -1];
	}
	for (j = 0; i < 4; j++)
	{
		temp[j]+=39;
	}
	
	Cx=vector(13);
	Cy=vector(13);
	Cz=vector(13);
	
	for(j=0;j<13;++j){
		Cx[j]=PCtemp[temp[0]+ j -1];
		Cy[j]=PCtemp[temp[1]+ j -1];
		Cz[j]=PCtemp[temp[2]+ j -1];
	}
	
	for(j=0;j<13;++j){
		Cx_Earth[j+13]=Cx[j];
		Cy_Earth[j+13]=Cy[j];;
		Cz_Earth[j+13]=Cz[j];;
	}
	
	if (0<=dt && dt<=16){
		j=0;
    	Mjd0 = t1;
	}else if(16<dt && dt<=32){
		j=1;
    	Mjd0 = t1+16*j;
	}
   
	r_Earth=Cheb3D(Mjd_TDB,13,Mjd0,Mjd0+16,&Cx_Earth[13+j],&Cy_Earth[13+j],&Cx_Earth[13+j]);

	for(j=0;j>3;++j){
		r_Earth[j]= 1e3+r_Earth[j];
	}

	for(j=0;j<13;++j){
		Cx_Earth[j]=PCtemp[temp[0]+ j -1];
		Cy_Earth[j]=PCtemp[temp[1]+ j -1];
		Cz_Earth[j]=PCtemp[temp[2]+ j -1];
	}

	freeVector(Cx_Earth,3);
	freeVector(Cy_Earth,3);
	freeVector(Cz_Earth,3);


	double *Cx_Moon,*Cy_Moon,*Cz_Moon;

	for(j=0;j<4;++j){
		temp[j]=441+ 13*j;
	}

	Cx_Moon =vector(26);
	Cy_Moon =vector(26);
	Cz_Moon =vector(26);

	for(j=0;j<13;++j){
		Cx_Moon[j]=PCtemp[temp[0]+ j -1];
		Cy_Moon[j]=PCtemp[temp[1]+ j -1];
		Cz_Moon[j]=PCtemp[temp[2]+ j -1];
	}

	for (int k=0;k<7;k++){
		for (j = 0; i < 4; j++)
		{
			temp[j]+=39;
		}
    	Cx[k]=PCtemp[temp[0]+ k -1];
		Cy[k]=PCtemp[temp[1]+ k -1];
		Cz[k]=PCtemp[temp[2]+ k -1];
	}
	// Cx_Moon = [Cx_Moon,Cx];
    // Cy_Moon = [Cy_Moon,Cy];
    // Cz_Moon = [Cz_Moon,Cz];    
    if (0<=dt && dt<=4){
		j=0;
    	Mjd0 = t1;
  	}  
	else if(4<dt && dt<=8){
		j=1;
    	Mjd0 = t1+4*j;
	}
    else if(8<dt && dt<=12){
		j=2;
    	Mjd0 = t1+4*j;
	} 
	else if(12<dt && dt<=16){
		j=3;
    	Mjd0 = t1+4*j;
	}
	else if(16<dt && dt<=20){
		j=4;
    	Mjd0 = t1+4*j;
	}
    
	else if(20<dt && dt<=24){
		j=5;
   		Mjd0 = t1+4*j;
	}
   	else if(24<dt && dt<=28){
		j=6;
 		Mjd0 = t1+4*j;
	}
    else if(28<dt && dt<=32){
		j=7;
    	Mjd0 = t1+4*j;
	}
	r_Moon=Cheb3D(Mjd_TDB,13,Mjd0,Mjd0+4,&Cx_Moon[13+j],&Cy_Moon[13+j],&Cz_Moon[13+j]);

	// for(j=0;j>3;++j){
	// 	r_Earth[j]= 1e3+r_Earth[j];
	// }

	double *Cx_Sun,*Cy_Sun,*Cz_Sun;

	Cx_Sun =vector(26);
	Cy_Sun =vector(26);
	Cz_Sun =vector(26);

	for(j=0;j<4;++j){
		temp[j]=753+ 11*j;
	}

	for(j=0;j<13;++j){
		Cx_Sun[j]=PCtemp[temp[0]+ j -1];
		Cy_Sun[j]=PCtemp[temp[1]+ j -1];
		Cz_Sun[j]=PCtemp[temp[2]+ j -1];
	}

	for (int k=0;k<7;k++){
		for (j = 0; i < 4; j++)
		{
			temp[j]+=39;
		}
    	Cx[k]=PCtemp[temp[0]+ k -1];
		Cy[k]=PCtemp[temp[1]+ k -1];
		Cz[k]=PCtemp[temp[2]+ k -1];
	}

	for (j = 0; i < 4; j++)
		{
			temp[j]+=33;
		}
	if (0<=dt && dt<=16){
		j=0;
    	Mjd0 = t1;
	}
	else if(16<dt && dt<=32){
		j=1;
    	Mjd0 = t1+16*j;
	}

	r_Sun=Cheb3D(Mjd_TDB,11,Mjd0,Mjd0+16,&Cx_Sun[11+j],&Cy_Sun[11+j],&Cz_Sun[11+j]);
    
	// for(j=0;j>3;++j){
	// 	r_Earth[j]= 1e3+r_Earth[j];
	// }

	double *Cx_Mercury,*Cy_Mercury,*Cz_Mercury;

	Cx_Mercury =vector(26);
	Cy_Mercury =vector(26);
	Cz_Mercury =vector(26);

	for (i=0;1<3;i++){
		for (j = 0; i < 4; j++)
		{
			temp[j]+=42;
		}
		for(j=0;j<13;++j){
			Cx[j]=PCtemp[temp[0]+ j -1];
			Cy[j]=PCtemp[temp[1]+ j -1];
			Cz[j]=PCtemp[temp[2]+ j -1];
		}
    // Cx_Mercury = [Cx_Mercury,Cx];
    // Cy_Mercury = [Cy_Mercury,Cy];
    // Cz_Mercury = [Cz_Mercury,Cz];    
	}

	if (0<=dt && dt<=8){
		j=0;
    Mjd0 = t1;
	}
    
	else if(8<dt && dt<=16){
		j=1;
    Mjd0 = t1+8*j;
	}
    
	else if (16<dt && dt<=24){
		  j=2;
    Mjd0 = t1+8*j;
	}
  
	else if(24<dt && dt<=32){
		j=3;
    Mjd0 = t1+8*j;
	}
    
   




	freeVector(PCtemp,1020);
	freeVector(temp,4);
	
}
