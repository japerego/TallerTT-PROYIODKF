//--------------------------------------------------------------------------
//
//  inputs:
//    vec1         - vector 1
//    vec2         - vector 2
//
//  output:
//    theta        - angle between the two vectors  -pi to pi
//
//--------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/sign.h"
/** @file angl.c
 *  @brief Function prototypes for the code driver.
 *
 *  Returns the angle between 2 vectors
 *
 *  @author japerego
 *  @bug No known bugs.
 */

double angl( double * vec1,int n1,double *vec2,int n2 ){

    double theta;
    double small     = 0.00000001;
    double undefined = 999999.1;

    double magv1 = norma(vec1,n1);
    double magv2 = norma(vec2,n2);

    if (magv1*magv2 > small*small){
        double temp= dot(vec1,n1,vec2,n2) / (magv1*magv2);
        if (fabs( temp ) > 1.0){
            //duda
            temp= temp/fabs(temp) * 1.0;
        }
        theta= acos( temp );
    
    }
    else{
        theta= undefined;
    }

    return theta;
}


