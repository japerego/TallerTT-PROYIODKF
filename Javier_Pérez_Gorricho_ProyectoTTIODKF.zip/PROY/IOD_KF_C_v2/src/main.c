#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/position.h"
#include "../include/R_x.h"
#include "../include/R_y.h"
#include "../include/R_z.h"
#include "../include/sign.h"
#include "../include/timediff.h"
#include "../include/unit.h"
#include "../include/angl.h"
#include "../include/Legendre.h"
#include "../include/TimeUpdate.h"
#include "../include/PoleMatrix.h"
#include "../include/Mjday.h"
#include "../include/Mjday_TDB.h"
#include "../include/NutMatrix.h"
#include "../include/PrexMatrix.h"
#include "../include/MeasUpdate.h"
#include "../include/MeanObliquity.h"
#include "../include/gmst.h"
#include "../include/Frac.h"
#include "../include/LTC.h"
#include "../include/Geodetic.h"
#include "../include/gibbs.h"
#include "../include/hgibbs.h"
#include "../include/NutAngles.h"
#include "../include/AccelPointMass.h"
#include "../include/EccAnom.h"
#include "../include/EqnEquinox.h"
#include "../include/gast.h"
#include "../include/AzelPa.h"
#include "../include/AccelHarmonic.h"
#include "../include/Cheb3D.h"
#include "../include/globales.h"
#include "../include/GHAmatrix.h"
#include "../include/IERS.h"
#include "../include/ode.h"

int main(){

	extern double **PC,**Cnm,**Snm,**eopdata,Mjd_TT,Mjd_UT1,TT_UTC,UT1_UTC;
    extern int n_eqn;
    extern Param AuxParam;

	double aux1,aux2,nobs,**obs; //**aux1,**aux2,**PC,**Cnm,**Snm,
	FILE *fp;
	int f,c,n,m,i,j,j2;
	PC=array(2285,1020);
	
	fp=fopen("../Datos/DE430Coeff.txt","r");
	if(fp==NULL){
		printf("Fallo al abrir ek fichero DE430Coeff.txt");
		exit(EXIT_FAILURE);	
	}
	for(f=0;f<2285;f++){
		for(c=0;c<1020;c++){
			fscanf(fp,"%lf", &PC[f][c]);
		}
	}

	fclose(fp);
	
	fp=fopen("../Datos/GGM03S.txt","r");

	if(fp==NULL){
		printf("Fallo al abrir ek fichero GGM03S.txt");
		exit(EXIT_FAILURE);	
	}
	Cnm=array(182,182);
	Snm=array(182,182);
	for(n=0;n<=180;n++){
		for(m=0;m<=n;m++){
		fscanf(fp,"%d%d%lf%lf%lf%lf",&f,&c, &Cnm[n+1][m+1], &Snm[n+1][m+1], &aux1, &aux2);
	}
	}
	
	fclose(fp);


	eopdata=array(13,21413);

	fp=fopen("../Datos/eop19620101.txt","r");
	if(fp==NULL){
		printf("Fallo al abrir el fichero eop19620101.txt");
		exit(EXIT_FAILURE);	
	}

	for(f=0;f<21413;f++){
		fscanf(fp,"%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf",&eopdata[0][f],&eopdata[1][f],&eopdata[2][f],&eopdata[3][f],&eopdata[4][f],&eopdata[5][f],&eopdata[6][f],&eopdata[7][f],&eopdata[8][f],&eopdata[9][f],&eopdata[10][f],&eopdata[11][f],&eopdata[12][f]);
	}

	fclose(fp);

	nobs=46;
	obs=array(nobs,4);

	fp=fopen("../Datos/GEOS3.txt","r");
	if(fp==NULL){
		printf("Fallo al abrir ek fichero GEOS3.txt");
		exit(EXIT_FAILURE);	
	}
	//Representados hi,mi,si por h,m,s no confundir con nuestros iteradores para futuras llamadas a estos
	int Y,M,D,hi,mi,si,az,el,Dist;
	char line[55],yc[5],mc[3],dc[3],hc[2],mnc[2],sc[6],ac[8],ec[8],dic[9];	

	//Linea + 2 por el salto de linea
	//Almacenamos en el vector de caracteres los 4 caracteres a continuacion de line0 y le añadimos '\0' 
	//atof de caracteres a numero real

	for (i=0;i<nobs;i++){
		fgets(line,sizeof(line)+2 , fp);
		//Sumamos 1 mas extra por la linea divisoria
		//Leemos años
		strncopy(yc,&line[0],4);
    	yc[4]='\0';
		Y=atoi(yc);
		//Leemos meses	
		strncopy(mc,&line[5],2);
		mc[2]='\0';
		M=atoi(mc);
		//Leemos dias
		strncopy(dc,&line[8],2);
		dc[2]='\0';
		D=atoi(dc);
		//Leemos horas
		//2 mas a la hora de leer por el espacio 
		strncopy(hc,&line[12],2);
		hc[2]='\0';
		hi=atoi(hc);
		//Sumamos 1 mas extra por los 2 puntos divisoria
		//Leemos minutos
		strncopy(mnc,&line[15],2);
		mnc[2]='\0';
		mi=atoi(mnc);
		//Leemos segundos
		strncopy(sc,&line[18],6);
		sc[6]='\0';
		si=atof(sc);

		strncopy(ac,&line[25],8);
		ac[8]='\0';
		az=atof(ac);

		strncopy(ec,&line[35],8);
		ec[8]='\0';
		el=atof(ec);

		strncopy(dic,&line[44],9);
		dic[9]='\0';
		Dist=atof(dic);

		obs[i][0] = Mjday(Y,M,D,hi,mi,si);
    	obs[i][1] = (Rad)*az;
    	obs[i][2] = (Rad)*el;
    	obs[i][3] = 1000*Dist;
	}
	/*
    Y = str2num(tline(1:4));
    M = str2num(tline(6:7));
    D = str2num(tline(9:10));
    h = str2num(tline(13:14));
    m = str2num(tline(16:17));
    s = str2num(tline(19:24));
    az = str2num(tline(26:33));
    el = str2num(tline(36:42));
    Dist = str2num(tline(45:54));
    obs(i,1) = Mjday(Y,M,D,h,m,s);
    obs(i,2) = const.Rad*az;
    obs(i,3) = const.Rad*el;
    obs(i,4) = 1e3*Dist;
	}
	*/

	double sigma_range,sigma_az,sigma_el,lat,lon,alt;

	sigma_range = 92.5;          // [m]
	sigma_az = 0.0224*(Rad); // [rad]
	sigma_el = 0.0139*(Rad); // [rad]


	// Kaena Point station
	lat = (Rad)*21.5748;     // [rad]
	lon = (Rad)*(-158.2706); // [rad]
	alt = 300.20;                // [m]
	
	double *Rs=vector(3);
	Rs = position(lon, lat, alt);

	//puede que haya que sumar uno a cada indice !
	double Mjd1,Mjd2,Mjd3,Mjd0;
	Mjd1 = obs[0][0];
	Mjd2 = obs[8][0];
	Mjd3 = obs[17][0];

/*
	[r2,v2] = anglesg(obs(1,2),obs(9,2),obs(18,2),obs(1,3),obs(9,3),obs(18,3),...
                  Mjd1,Mjd2,Mjd3,Rs,Rs,Rs);

-------------------------------OPCIONAL----------------------------------------------------------------------
% [r2,v2] = anglesdr(obs(1,2),obs(9,2),obs(18,2),obs(1,3),obs(9,3),obs(18,3),...
%                    Mjd1,Mjd2,Mjd3,Rs,Rs,Rs);
-------------------------------OPCIONAL----------------------------------------------------------------------
*/


	int n_eqn = 6;
  	double t = 0.0;
  	double relerr = 1e-13;
 	double abserr = 1e-6;
  	double *work = vector(100 + 21 * n_eqn);
  	double* YY =vector(6);
	double *Y0_apr=vector(6);
	int iflag=1;
	

	Y0_apr[0]=6221397.62857869;
	Y0_apr[1]=2867713.77965741;
	Y0_apr[2]=3006155.9850995;
	Y0_apr[3]=4645.0472516175;
	Y0_apr[4]=-2752.21591588182;
	Y0_apr[5]=-7507.99940986939;

	double Mjd0=Mjday(1995,1,29,02,38,0);

	double Mjd_UTC=obs[8][0];

	AuxParam.Mjd_UTC = Mjd_UTC;
	AuxParam.n      = 20;
	AuxParam.m      = 20;
	AuxParam.sun     = 1;
	AuxParam.moon    = 1;
	AuxParam.planets = 1;

  	for(int i = 0; i < 6; ++i){
  		YY[i] = Y0_apr[i];
  	}
	//Integrador
  	//ode(Accel, n_eqn, YY, &t, -(obs[8][0]-Mjd0)*86400.0, relerr, abserr, &iflag, work, iwork );
  	
  	double ** P;
  	P= array(6,6);
  	
	for(i=0;i<3;++i){
		  P[i][i]=100000000;
		  P[i+3][i+3]=1000;
	} 
	double **LT=array(3,3);
    LT=LTC(lon,lat);

	double *yPhi,**Phi,*Y_old,x_pole,y_pole,LOD,dpsi,deps,dx_pole,dy_pole,TAI_UTC,UT1_TAI,UTC_GPS,UT1_GPS,GPS_UTC;

	yPhi = vector(42);
	Phi  = array(6,6);
	Y_old =vector(6);

	t = 0;
	int t_old;

	double *s,*r,**Qdt,*Azim,*Elev, *dAds,* dEds,*dAdY,*dEdY,*dDdy;	
	dDdy=vector(6);
	dEdY=vector(6);
	dAdY=vector(6);
	Qdt=array(6,6);
	double *dDds = vector(3);
	for(i=0;i<nobs;++i){
		t_old=t;

		for (  j = 0; j < 6; j++)
		{
			Y_old[j]=YY[j];
		}

		Mjd_UTC = obs[i][0];                       // Modified Julian Date
    	t = (Mjd_UTC-Mjd0)*86400.0;  


		IERS(eopdata,Mjd_UTC,'l',&x_pole,&y_pole,&UT1_UTC,&LOD,&dpsi,&deps,&dx_pole,&dy_pole,&TAI_UTC);
    	timediff(UT1_UTC,TAI_UTC,&UT1_TAI,&UTC_GPS,&UT1_GPS,&TT_UTC,&GPS_UTC);
    	Mjd_TT = Mjd_UTC + TT_UTC/86400;
    	Mjd_UT1 = Mjd_TT + (UT1_UTC-TT_UTC)/86400.0;
   		AuxParam.Mjd_UTC = Mjd_UTC;
    	AuxParam.Mjd_TT = Mjd_TT;
		for (  j2 = 0; j2 < 6; j2++)
		{
			yPhi[j2] = Y_old[j2];
        	for (j=0;j<6;++j){
				if (j2==j){
					yPhi[6*j+j2] = 1; 
				} 
            	else{
					yPhi[6*j+j2] = 0;
				}
			}  
		}

		//yPhi = ode (@VarEqn,0,t-t_old,1e-13,1e-6,42,yPhi);
		
	

    	double theta, **U;	

		for(int k=0;k<6;k++){
			for (j=0;j<6;j++){
        		Phi[k][j] = yPhi[6*j+k+1];
			}

		}

		//YY = ode (@Accel,0,t-t_old,1e-13,1e-6,6,Y_old);


		theta = gmst(Mjd_UT1);                    //Earth rotation
    	U = R_z(theta);
    	
		for(int k=0;k<3;k++){
			r[k] = YY[k];  //Aun queda declarar r;
		}
   	 	s = mat_x_vec(LT,3,3,mat_x_vec(U,3,3,restaVectores(r,Rs,3),3),3);                          //Topocentric position [m]

			
		P = TimeUpdate(P, Phi,Qdt,6);

		AzElPa(s,Azim, Elev, dAds, dEds);     // Azimuth, Elevation
    	
		dAdY = mat_x_vec(U,3,3, mat_x_vec(LT,3,3,dAds,3),3);
		dAdY[3]=0.0;
		dAdY[4]=0.0;
		dAdY[5]=0.0;

		//---------------------------------IMPLEMENTAR-----------------------------------
		//[K, Y, P] = MeasUpdate ( YY, obs[I-1][1], Azim, sigma_az, dAdY, P, 6 );


		for(int k=0;k<3;k++){
			r[k] = YY[k];  
		}
    	s = mat_x_vec(LT,3,3,mat_x_vec(U,3,3,restaVectores(r,Rs,3),3),3);    //Topocentric position [m]
    	AzElPa(s,Azim, Elev, dAds, dEds);     // Azimuth, Elevation
    	dEdY = mat_x_vec(U,3,3, mat_x_vec(LT,3,3,dEds,3),3);
		dEdY[3]=0.0;
		dEdY[4]=0.0;
		dEdY[5]=0.0;

		//---------------------------------IMPLEMENTAR-----------------------------------
		//[K, Y, P] = MeasUpdate ( YyÇY, obs[i-1][2], Elev, sigma_el, dEdY, P, 6 );

		
   			//Range and partials
			for(int k=0;k<3;k++){
				r[k] = YY[k];
			}
    	
    	s =mat_x_vec (LT,3,3,(restaVectores(mat_x_vec(U,3,3,r,3),Rs,3),3),3);                          // Topocentric position [m]
   		Dist = norma(s,3); 
		dDds = esc_x_vec(1/Dist,s,3);         //Range
    	dDdy = mat_x_vec(U,3,3, mat_x_vec(LT,3,3,dDds,3),3);
		dDdy[3]=0.0;
		dDdy[4]=0.0;
		dDdy[5]=0.0;

		//---------------------------------IMPLEMENTAR-----------------------------------
    	//[K, Y, P] = MeasUpdate ( YY, obs[i-1][3], Dist, sigma_range, dDdY, P, 6 );

    }	
	//PUEDE QUE HAYA QUE BAJAR 1 A LOS INDICES DE OBS
	IERS(eopdata,obs[46][1],'l',&x_pole,&y_pole,&UT1_UTC,&LOD,&dpsi,&deps,&dx_pole,&dy_pole,&TAI_UTC);
	timediff(UT1_UTC,TAI_UTC,&UT1_TAI,&UTC_GPS,&UT1_GPS,&TT_UTC,&GPS_UTC);
	Mjd_TT = Mjd_UTC + TT_UTC/86400;
	AuxParam.Mjd_UTC = Mjd_UTC;
	AuxParam.Mjd_TT = Mjd_TT;

	/*
	//---------------------------------IMPLEMENTAR-----------------------------------
	Y0 = DEInteg (@Accel,0,-(obs[45][0]-obs[0][0])*86400.0,1e-13,1e-6,6,Y);
	
	*/
	double Y_true []= {5753.173e3, 2673.361e3, 3440.304e3, 4.324207e3, -1.924299e3, -5.728216e3};
	

	printf("\n Error of Position Estimation \n");
	printf("%5.15lf [m]\n",Y0_apr[0]-Y_true[0]);
	printf("%5.15lf [m]\n",Y0_apr[1]-Y_true[1]);
	printf("%5.15lf [m]\n",Y0_apr[2]-Y_true[2]);
	printf("\n Error of Velocity Estimation \n");
	printf("%5.15lf [m/s]\n",Y0_apr[3]-Y_true[3]);
	printf("%5.15lf [m/s]\n",Y0_apr[4]-Y_true[4]);
	printf("%5.15lf [m/s]\n",Y0_apr[5]-Y_true[5]);

	freeArray(LT,3,3);
	freeArray(P,6,6);
	freeVector(yPhi,42);
	freeArray(Phi,6,6);
	freeVector(Y_old,6);
	freeVector(work,100 + 21 * n_eqn);
  	freeVector(YY,6);
	freeVector(Y0_apr,6);
	freeArray(PC,2285,1020);
	freeArray(Cnm,182,182);
	freeArray(Snm,182,182);
	freeArray(eopdata,13,21413);
	
	
	return 0;
}
