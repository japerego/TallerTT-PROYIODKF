//--------------------------------------------------------------------------
//
// Purpose:
//  Computes azimuth, elevation and partials from local tangent coordinates
//
// Input:
//   s      Topocentric local tangent coordinates (East-North-Zenith frame)
// 
// Outputs:
//   A      Azimuth [rad]
//   E      Elevation [rad]
//   dAds   Partials of azimuth w.r.t. s
//   dEds   Partials of elevation w.r.t. s
//
// Last modified:   2015/08/12   M. Mahooti
//
//--------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"

/** @file AzelPa.c
 *  @brief A code driver.
 *
 *  Computes azimuth, elevation and partials from local tangent coordinates
 *
 *  @author japerego
 *  @bug No known bugs.
 */
void AzElPa(double *s, double *Az, double *El, double *dAds, double *dEds)
{

	double rho = sqrt(s[0]*s[0]+s[1]*s[1]);

// Angles
	*Az = atan2(s[0],s[1]);

if ((*Az)<0.0) {
	*Az = *Az+pi2;
}
*El = atan ( s[2] / rho );

// Partials

dAds[0] = s[1]/(rho*rho);
dAds[1]=-s[0]/(rho*rho);
dAds[2]= 0.0;
dEds[0] = -s[0]*s[2] /rho;
dEds[1] =-s[1]*s[2] /rho ;
dEds[2]=  rho ;

double div=dot(s,3,s,3);

for(int j=0;j<3;++j){
	dEds[j] = dEds[j]/div;
}
}



