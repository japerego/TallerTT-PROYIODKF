#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"



/** @file Geodetic.c
 *  @brief A code driver.
 *
 *  geodetic coordinates (Longitude [rad], latitude [rad], altitude [m])   from given position vector (r [m])
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
void Geodetic(double * r,double * lon,double * lat,double * h){

double Nh,ZdZ,N,dZ,SinPhi,dZ_new;

double epsRequ = 2.220446049250313e-16 *R_Earth;       
double e2      = f_Earth*(2.0-f_Earth);        

double X = r[0];                 
double Y = r[1];
double Z = r[2];
double rho2 = X*X + Y*Y;          

if (norma(r,3)==0.0){
    printf( "invalid input in Geodetic constructor\n");
    *lon = 0.0;
    *lat = 0.0;
    *h   = -R_Earth;
}

dZ = e2*Z;

while(1){
    ZdZ    =  Z + dZ;
    Nh     =  sqrt ( rho2 + ZdZ*ZdZ ); 
    //printf("%5.15lf Nh \n",Nh);
    SinPhi =  ZdZ / Nh;                   
    N      =  R_Earth / (sqrt(1.0-e2*SinPhi*SinPhi));
    //printf("%5.15lf N \n",N);
    dZ_new =  N*e2*SinPhi;
    if ( fabs(dZ-dZ_new) < epsRequ ){
    	break;
    }
        
    dZ = dZ_new;
    
}
    
*lon = atan2 ( Y, X );
*lat = atan2 ( ZdZ, sqrt(rho2) );
*h   = Nh - N;

}
