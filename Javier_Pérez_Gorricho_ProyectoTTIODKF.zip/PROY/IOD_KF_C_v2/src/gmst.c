#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/Frac.h"

/** @file gmst.c
 *  @brief A code driver.
 *
 *  Greenwich Mean Sidereal Time
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double gmst(double Mjd_UT1){
	double Secs=86400.0;
	
	double MJD_2m=51544.5;
	
	double Mjd_0=floor(Mjd_UT1);
	double UT1=Secs*(Mjd_UT1-Mjd_0);
	
	double T_0=(Mjd_0-MJD_2m)/36525.0;
	double T=(Mjd_UT1-MJD_2m)/36525.0;
	
	double gmst=24110.54841 + 8640184.812866 * T_0 + 1.002737909350795 * UT1 + (0.093104-6.2e-6*T) *T *T;
        
        double gmstime = 2*pi*frac(gmst/Secs); 
        
        return gmstime;
}
