/*
function gstime = gast (Mjd_UT1)

gstime = mod ( gmst(Mjd_UT1) + EqnEquinox(Mjd_UT1), 2*pi );

*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/gmst.h"
#include "../include/EqnEquinox.h"

/** @file gast.c
 *  @brief A code driver.
 *
 *  Greenwich Apparent Sidereal Time
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double gast(double Mjd_UT1){
	double vuelta;
	vuelta= gmst(Mjd_UT1) + fmod(EqnEquinox(Mjd_UT1),2*pi);
	
	return vuelta;
}

