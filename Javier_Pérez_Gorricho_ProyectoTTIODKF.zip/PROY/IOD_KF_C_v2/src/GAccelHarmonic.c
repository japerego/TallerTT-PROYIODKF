
//--------------------------------------------------------------------------
//
// G_AccelHarmonic.m
//
// Purpose:
//   Computes the gradient of the Earth's harmonic gravity field 
//
// Inputs:
//   r           Satellite position vector in the true-of-date system
//   U           Transformation matrix to body-fixed system
//   n           Gravity model degree
//   m 			Gravity model order
//
// Output:
//   G    		Gradient (G=da/dr) in the true-of-date system
//
// Last modified:   2015/08/12   M. Mahooti
//
//--------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/AccelHarmonic.h"
/** @file GAccelHarmonic.c
 *  @brief A code driver.
 *
 *  Computes the gradient of the Earth's harmonic gravity field 
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double ** G_AccelHarmonic( double *r, double ** U,int nU, int n_max,int m_max )
{

	double d = 1.0;   // Position increment [m]
	double **G = array(3,3);
	double *dr = vector(3);

	double *da;
	double *ah1,*ah2;

	// Gradient
	for (int i=0;i<3;++i){
		
		// Set offset in i-th component of the position vector
		for(int j=0;j<3;++j){
			dr[j] = 0.0;
		}
    	dr[i] = d/2;
		//printVector(sumaVectores(r,dr,3),3);
		
    	// Acceleration difference
		//da1=AccelHarmonic(sumaVectores(r,dr,3),U,3,n_max,m_max);
		//da2=AccelHarmonic(sumaVectores(r,esc_x_vec(-1.0,dr,3),3),U,3,n_max,m_max);
		

		ah1=AccelHarmonic(sumaVectores(r,dr,3),U,nU, n_max, m_max );
		// printf("Vector ah1 \n");
		// printVector(ah1,3);
		// printf(" \n");
		ah2=AccelHarmonic (restaVectores(r,dr,3),U,nU, n_max, m_max );
		// printf("Vector ah1 \n");
		// printVector(ah2,3);
		// printf(" \n");
    	da = restaVectores(ah1,ah2,3);

		// printf("Vector da \n");
		// printVector(da,3);

		// printf(" \n");
    	// Derivative with respect to i-th axis
   		for (int c = 0; c < 3; c++)
	   	{
			G[c][i]=da[c]/d;
	  	}   
		freeVector(da,3);
	}
	
	freeVector(dr,3);
	//printArray(U,3,3);
	return G;
}

