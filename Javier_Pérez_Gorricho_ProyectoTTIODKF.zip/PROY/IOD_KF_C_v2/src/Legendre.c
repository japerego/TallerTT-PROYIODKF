#include "../include/iodkf.h"
#include "../include/arrays.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
/** @file Legendre.c
 *  @brief A code driver.
 *
 *  
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
void Legendre(int n, int m, double fi, double **pnm, double **dpnm)
{
	pnm[0][0] = 1;
	dpnm[0][0] = 0;
	pnm[1][1] = sqrt(3) * cos(fi);
	dpnm[1][1] = -sqrt(3) * sin(fi);

	//Diagonal primera matriz saltandose el 0
	for (int i = 1; i < n; i++)
	{
		pnm[i + 1][ i + 1] = sqrt((2.0 * (i+1) + 1) / (2.0 * (i+1))) * cos(fi) * pnm[i][i];
	}
	//Diagonal segunda matriz saltandose el 0
	for (int i = 1; i <n; i++)
	{
		dpnm[i + 1][i + 1] = sqrt((2.0 * (i+1) + 1) / (2.0 * (i+1))) * ((cos(fi) * dpnm[i][i]) - (sin(fi) * pnm[i][i]));

	}

	//Siguientes filas  primera matriz saltandose el 0,0
	for (int i = 0; i < n; i++)
	{
		//Problemas con las filas debido a que de multiplicaba dentro de la raiz por i y esta era igual a una iteracion menor, por tanto afectaba el resultado i-->(i+1) 
		//Aplicable para dpnm
		pnm[i + 1] [i] = sqrt(2.0 * (i+1) + 1) * sin(fi) * pnm[i][i];
		// printf("Dentro de siguientes filas primera matriz");
		// printf("%5.15lf",pnm[i+1][i]);
	}


	//Siguientes filas segunda  matriz saltandose el 0,0
	for (int i = 0; i < n; i++)
	{
		dpnm[i + 1][i] = sqrt(2.0 * (i+1) + 1) * ((cos(fi) * pnm[i][i]) + (sin(fi) * dpnm[i][i]));
	}

	int j = 0, k = 1;

	while(1)
	{
		for (int i = k; i < n; i++)
		{

			pnm[i + 1][j] = sqrt((2.0 * (i+1) + 1) / ((1.0 * (i+1) - j) * (1.0 * (i+1) + j))) * ((sqrt(2.0 * (i+1) - 1) * sin(fi) * pnm[i][j])- (sqrt(((1.0 * (i+1) + j - 1.0) * (1.0 * (i+1) - j - 1.0)) / (2.0 * (i+1) - 3)) * pnm[i - 1][j]));

		}


		j = j + 1;
		k = k + 1;
		if (j > m)
		{
			break;
		}	
	}

	j = 0;
	k = 1;
	
	while (1)
	{
		for (int i = k; i < n; i++)
		{
			dpnm[i + 1][j] = sqrt((2.0 * (i+1) + 1) / ((1.0 * (i+1) - 1.0 * j) * (1.0 * (i+1) + j))) * ((sqrt(2.0 * (i+1) - 1) * sin(fi) * dpnm[i][j])+ (sqrt(2.0 * (i+1) - 1) * cos(fi) * pnm[i][j]) - (sqrt(((1.0 * (i+1) + j - 1.0) * (1.0 * (i+1) - j - 1.0)) / (2.0 * (i+1) - 3)) * dpnm[i - 1][j]));

		}

		j = j + 1;
		k = k + 1;
		if (j > m)
		{
			break;
		}
	}

}