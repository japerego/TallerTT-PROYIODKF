#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/angl.h"
#include "../include/unit.h"
#include "../include/iodkf.h"
#include <string.h>
/*
hgibbs.m
%
%  this function implements the herrick-gibbs approximation for orbit
%  determination, and finds the middle velocity vector for the 3 given
%  position vectors.
%
%  inputs:
%    r1          - ijk position vector #1         m
%    r2          - ijk position vector #2         m
%    r3          - ijk position vector #3         m
%    Mjd1        - julian date of 1st sighting    days from 4713 bc
%    Mjd2        - julian date of 2nd sighting    days from 4713 bc
%    Mjd3        - julian date of 3rd sighting    days from 4713 bc
%
%  outputs:
%    v2          - ijk velocity vector for r2     m/s
%    theta       - angl between vectors           rad
%    error       - flag indicating success        'ok',...
%

function [v2, theta,theta1,copa, error] = hgibbs (r1,r2,r3,Mjd1,Mjd2,Mjd3)
*/

/** @file hgibbs.c
 *  @brief A code driver.
 *
 * this function implements the herrick-gibbs approximation for orbit determination, and finds the middle velocity vector for the 3 given position vectors.
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
void hgibbs(double * r1,double * r2,double * r3,double Mjd1,double Mjd2,double Mjd3,double * v2,double *theta,double * theta1,double * copa, char error[255]){
	double magr1,magr2,magr3,dt21,dt31,dt32;
	//SAT_Const

	strcpy(error,"ok");
	*theta = 0.0;
	*theta1= 0.0;
	magr1 = norma( r1 ,3);
	magr2 = norma( r2 ,3);
	magr3 = norma( r3 ,3);
	for (int i=0; i<3;++i){
		v2[i]=0.0;
	}
	
	double tolangle= 0.01745329251994;
	
	dt21= (Mjd2-Mjd1)*86400.0;
	dt31= (Mjd3-Mjd1)*86400.0;
	dt32= (Mjd3-Mjd2)*86400.0;

	double *p,*pn,*r1n;

	p = cross( r2,3,r3,3 );
	pn = unit( p,3 );
	r1n = unit( r1,3 );
	*copa=  asin( dot( pn,3,r1n,3 ) );

	if ( abs( dot(r1n,3,pn,3) ) > 0.017452406 ){
    	strcpy(error,"not coplanar");
	}
	(*theta)  = angl( r1,3,r2,3 );
	(*theta1) = angl( r2,3,r3,3 );

	if ( ((*theta) > tolangle) | ((*theta1) > tolangle) )  {
		strcpy(error,"angl > 1ø");
	}

	double term1,term2,term3;

	term1= -dt32*( 1.0/(dt21*dt31) + GM_Earth/(12.0*magr1*magr1*magr1) );
	term2= (dt32-dt21)*( 1.0/(dt21*dt32) + GM_Earth/(12.0*magr2*magr2*magr2) );
	term3=  dt21*( 1.0/(dt32*dt31) + GM_Earth/(12.0*magr3*magr3*magr3) );

	double *aux;
	aux = sumaVectores(sumaVectores(esc_x_vec(term1,r1,3),esc_x_vec(term2,r2,3),3),esc_x_vec(term3,r3,3),3);
		//printVector(aux,3);

		for(int i=0;i<3;i++){
			v2[i]=aux[i];
		}

	
	//printVector(v2,3);
	freeVector(aux,3);
	freeVector(r1n,3);
	freeVector(p,3);
	freeVector(pn,3);

}


/*


p = cross( r2,r3 );
pn = unit( p );
r1n = unit( r1 );
copa=  asin( dot( pn,r1n ) );

if ( abs( dot(r1n,pn) ) > 0.017452406 )
    error= 'not coplanar';
end

theta  = angl( r1,r2 );
theta1 = angl( r2,r3 );

if ( (theta > tolangle) | (theta1 > tolangle) )  
    error= '   angl > 1ø';
end

term1= -dt32*( 1.0/(dt21*dt31) + GM_Earth/(12.0*magr1*magr1*magr1) );
term2= (dt32-dt21)*( 1.0/(dt21*dt32) + GM_Earth/(12.0*magr2*magr2*magr2) );
term3=  dt21*( 1.0/(dt32*dt31) + GM_Earth/(12.0*magr3*magr3*magr3) );

v2 =  term1*r1 + term2* r2 + term3* r3;
*/

