#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
/** @file Frac.c
 *  @brief A code driver.
 *
 *  Fractional part of a number (y=x-[x])
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double frac(double x){
	return x-floor(x);
 }


