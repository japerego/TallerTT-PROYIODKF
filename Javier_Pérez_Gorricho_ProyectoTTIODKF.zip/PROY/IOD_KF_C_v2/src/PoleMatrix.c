//--------------------------------------------------------------------------
//
// PoleMatrix.m
//
// Purpose:
//   Transformation from pseudo Earth-fixed to Earth-fixed coordinates
//   for a given date
//
// Input:
//   Pole coordinte(xp,yp)
//
// Output:
//   PoleMat   Pole matrix
//
// Last modified:   2015/08/12   M. Mahooti
// 
//--------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include "../include/arrays.h"
#include "../include/R_x.h"
#include "../include/R_y.h"
/** @file PoleMatrix.c
 *  @brief A code driver.
 *
 *  Transformation from pseudo Earth-fixed to Earth-fixed coordinates for a given date
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double **  PoleMatrix (double xp,double yp){
	double **PoleMat = prod(R_y(-xp),3,3, R_x(-yp),3,3);
	return PoleMat;
}
 

