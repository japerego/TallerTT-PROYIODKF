#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
/** @file sign.C
 *  @brief A code driver.
 *
 *  returns absolute value of a with sign of b
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double sign_(double a,double b){
	if(b>=0.0){
		return fabs(a);
	}
	else{
		return -fabs(a);
	}
}
