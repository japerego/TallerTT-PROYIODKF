/*
//--------------------------------------------------------------------------
//
// IERS: Management of IERS time and polar motion data
//  
// Last modified:   2018/02/01   M. Mahooti
// 
//--------------------------------------------------------------------------
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
/** @file IERS.c
 *  @brief A code driver.
 *
 *  Computes the gradient of the Earth's harmonic gravity field 
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
void IERS(double ** eop,double Mjd_UTC,char interp,double *x_pole,double  *y_pole,double  *UT1_UTC,double  *LOD,double *dpsi,double *deps,double *dx_pole,double *dy_pole,double *TAI_UTC ){
    /*
    if (nargin == 2)
        interp = 'n';
    end
    */
   int i=0,ind;
   double mjd,mfme,fixf;
   double *preeop,*nexteop;

   if (interp =='l'){
        // linear interpolation
        mjd = (floor(Mjd_UTC));
        //Buscar en la matriz para la fila 4 la columna que sea igual a mjd
        double * eopfila3=vector(21413);
        for(i=0;i<21413;i++){
            eopfila3[i]=eop[3][i];
        }
        ind = findSOLO(eopfila3,21413,mjd);

        preeop=vector(13);
        nexteop=vector(13);
        double * eop2=vector(13);
        for(i=0;i<13;i++){
            preeop[i] = eop[i][ind];
            nexteop[i] = eop[i][ind+1];
        }
        //Obtener columna i
 
        mfme = 1440*(Mjd_UTC-floor(Mjd_UTC));
        fixf = mfme/1440;

        // Setting of IERS Earth rotation parameters
        // (UT1-UTC [s], TAI-UTC [s], x ["], y ["])

        *x_pole  = preeop[4]+(nexteop[4]-preeop[4])*fixf;
        *y_pole  = preeop[5]+(nexteop[5]-preeop[5])*fixf;
	    *UT1_UTC = preeop[6]+(nexteop[6]-preeop[6])*fixf;
        *LOD     = preeop[7]+(nexteop[7]-preeop[7])*fixf;
        *dpsi    = preeop[8]+(nexteop[8]-preeop[8])*fixf;
        *deps    = preeop[9]+(nexteop[9]-preeop[9])*fixf;
        *dx_pole = preeop[10]+(nexteop[10]-preeop[10])*fixf;
        *dy_pole = preeop[11]+(nexteop[11]-preeop[11])*fixf;
        *TAI_UTC = preeop[12];
	
        *x_pole  = *x_pole/(Arcs);  // Pole coordinate [rad]
        *y_pole  = *y_pole/(Arcs);  // Pole coordinate [rad]
        *dpsi    = *dpsi/(Arcs);
        *deps    = *deps/(Arcs);
        *dx_pole = *dx_pole/(Arcs); // Pole coordinate [rad]
        *dy_pole = *dy_pole/(Arcs); // Pole coordinate [rad]
    }
    else if (interp =='n')  {

         mjd = (floor(Mjd_UTC));
        //Buscar en la matriz para la fila 4 la columna que sea igual a mjd
        double * eopfila3=vector(21413);
        for(i=0;i<21413;i++){
            eopfila3[i]=eop[3][i];
        }
        ind = findSOLO(eopfila3,21413,mjd);

        double * eop2=vector(13);
        for(i=0;i<13;i++){
            eop2[i] = eop[i][ind];
        }
        *x_pole  = eop2[4]/(Arcs);  // Pole coordinate [rad]
        *y_pole  = eop2[5]/(Arcs);  // Pole coordinate [rad]
	    *UT1_UTC = eop2[6];             // UT1-UTC time difference [s]
        *LOD     = eop2[7];             // Length of day [s]
        *dpsi    = eop2[8]/(Arcs);
        *deps    = eop2[9]/(Arcs);
        *dx_pole = eop2[10]/(Arcs); // Pole coordinate [rad]
        *dy_pole = eop2[11]/(Arcs); // Pole coordinate [rad]
	    *TAI_UTC = eop2[12];            // TAI-UTC time difference [s]

    }  
    
}

/*
function [x_pole,y_pole,UT1_UTC,LOD,dpsi,deps,dx_pole,dy_pole,TAI_UTC] = IERS(eop,Mjd_UTC,interp)

global const

if (nargin == 2)
   interp = 'n';
end

if (interp =='l')
    // linear interpolation
    mjd = (floor(Mjd_UTC));
    i = find(mjd==eop(4,:),1,'first');
    preeop = eop(:,i);
    nexteop = eop(:,i+1);
    mfme = 1440*(Mjd_UTC-floor(Mjd_UTC));
    fixf = mfme/1440;
    // Setting of IERS Earth rotation parameters
    // (UT1-UTC [s], TAI-UTC [s], x ["], y ["])
    x_pole  = preeop(5)+(nexteop(5)-preeop(5))*fixf;
    y_pole  = preeop(6)+(nexteop(6)-preeop(6))*fixf;
	UT1_UTC = preeop(7)+(nexteop(7)-preeop(7))*fixf;
    LOD     = preeop(8)+(nexteop(8)-preeop(8))*fixf;
    dpsi    = preeop(9)+(nexteop(9)-preeop(9))*fixf;
    deps    = preeop(10)+(nexteop(10)-preeop(10))*fixf;
    dx_pole = preeop(11)+(nexteop(11)-preeop(11))*fixf;
    dy_pole = preeop(12)+(nexteop(12)-preeop(12))*fixf;
    TAI_UTC = preeop(13);
	
    x_pole  = x_pole/const.Arcs;  // Pole coordinate [rad]
    y_pole  = y_pole/const.Arcs;  // Pole coordinate [rad]
    dpsi    = dpsi/const.Arcs;
    deps    = deps/const.Arcs;
    dx_pole = dx_pole/const.Arcs; // Pole coordinate [rad]
    dy_pole = dy_pole/const.Arcs; // Pole coordinate [rad]
elseif (interp =='n')    
    mjd = (floor(Mjd_UTC));
    i = find(mjd==eop(4,:),1,'first');
    eop = eop(:,i);
    // Setting of IERS Earth rotation parameters
    // (UT1-UTC [s], TAI-UTC [s], x ["], y ["])
    x_pole  = eop(5)/const.Arcs;  // Pole coordinate [rad]
    y_pole  = eop(6)/const.Arcs;  // Pole coordinate [rad]
	UT1_UTC = eop(7);             // UT1-UTC time difference [s]
    LOD     = eop(8);             // Length of day [s]
    dpsi    = eop(9)/const.Arcs;
    deps    = eop(10)/const.Arcs;
    dx_pole = eop(11)/const.Arcs; // Pole coordinate [rad]
    dy_pole = eop(12)/const.Arcs; // Pole coordinate [rad]
	TAI_UTC = eop(13);            // TAI-UTC time difference [s]
end
*/
