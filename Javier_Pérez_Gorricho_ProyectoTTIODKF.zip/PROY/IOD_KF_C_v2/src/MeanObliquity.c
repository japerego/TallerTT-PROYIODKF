#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
/** @file MeanObliquity.c
 *  @brief A code driver.
 *
 *  Computes the mean obliquity of the ecliptic
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double MeanObliquity(double Mdj_TT){
	//global const

	double T = (Mdj_TT-MJD_J2000)/36525;

	double MOblq = Rad *( 84381.448/3600-(46.8150+(0.00059-0.001813*T)*T)*T/3600 );
	
	return MOblq;

}

