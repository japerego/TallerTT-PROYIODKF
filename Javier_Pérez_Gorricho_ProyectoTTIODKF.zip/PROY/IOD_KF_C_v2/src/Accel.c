#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/GHAmatrix.h"
#include "../include/AccelPointMass.h"
#include "../include/AccelHarmonic.h"
#include "../include/IERS.h"
#include "../include/globales.h"
/** @file Accel.c
 *  @brief A code driver.
 *
 *  Computes the acceleration of an Earth orbiting satellite due to 
     - the Earth's harmonic gravity field, 
     - the gravitational perturbations of the Sun and Moon
     - the solar radiation pressure and
     - the atmospheric drag
 *
 *  @author japerego
 *  @bug No known bugs.
 */
double * Accel(double x, double y){
	extern double ** eopdata;
	extern Param AuxParam;
	
	double x_pole,y_pole,UT1_UTC, LOD , dx_pole, dy_pole, Mjd_TT, TAI_UTC,MJD_TDB,Mjd_UT1 ,**P,**N,**T,**E,dpsi,deps,TT_UTC,*Y;
	
	double * r_Mercury,*r_Venus,*r_Earth,*r_Mars,*r_Jupiter,*r_Saturn,*r_Uranus,*r_Neptune,*r_Pluto,*r_Moon,*r_Sun;
	
	IERS(eopdata,AuxParam.Mjd_UTC+ x/86400,'l',&x_pole,&y_pole,&UT1_UTC,&LOD,&dpsi,&deps,&dx_pole,&dy_pole,&TAI_UTC);
	
	Mjd_UT1 = AuxParam.Mjd_UTC + x/86400 + UT1_UTC/86400;
	Mjd_TT = AuxParam.Mjd_UTC + x/86400 + TT_UTC/86400;

	P = PrecMatrix(MJD_J2000,Mjd_TT);
	N = NutMatrix(Mjd_TT);
	
	T = prod(N,3,3,P,3,3);
	
	E = prod(prod(PoleMatrix(x_pole,y_pole),3,3, GHAMatrix(Mjd_UT1),3,3),3,3 , T,3,3);

	MJD_TDB = Mjday_TDB(Mjd_TT);
	 
	JPL_Eph_DE430(MJD_TDB,r_Mercury,r_Venus,r_Earth,r_Mars,r_Jupiter,r_Saturn,r_Uranus,r_Neptune,r_Pluto,r_Moon,r_Sun);


	double * a = AccelHarmonic(Y, E, 3,AuxParam.n, AuxParam.m);

if (AuxParam.sun){
	a = sumV(a ,3, AccelPointMass(Y,3,r_Sun,3,GM_Sun),3);
}

if (AuxParam.moon){
 a = sumV(a ,3, AccelPointMass(Y,3,r_Moon,3,GM_Moon),3);
}
  


if (AuxParam.planets){
    	a = sumV(a ,3, AccelPointMass(Y,3,r_Mercury,3,GM_Mercury),3);
    	a = sumV(a ,3, AccelPointMass(Y,3,r_Venus,3,GM_Venus),3);
		a = sumV(a ,3, AccelPointMass(Y,3,r_Mars,3,GM_Mars),3);
    	a = sumV(a ,3, AccelPointMass(Y,3,r_Jupiter,3,GM_Jupiter),3);
    	a = sumV(a ,3, AccelPointMass(Y,3,r_Saturn,3,GM_Saturn),3);
    	a = sumV(a ,3, AccelPointMass(Y,3,r_Uranus,3,GM_Uranus),3);   
    	a = sumV(a ,3, AccelPointMass(Y,3,r_Neptune,3,GM_Neptune),3);;
    	a = sumV(a ,3, AccelPointMass(Y,3,r_Pluto,3,GM_Pluto),3);
}

int i=0;
double *dy=vector(6);
for(i=0;i<3;++i){
	dy[i]=Y[3+i];
}
for(i=0;i<3;++i){
	dy[i+3]=a[i];
}

return dy;


}
