//--------------------------------------------------------------------------
//
// Chebyshev approximation of 3-dimensional vectors
//
// Inputs:
//     N       Number of coefficients
//     Ta      Begin interval
//     Tb      End interval
//     Cx      Coefficients of Chebyshev polyomial (x-coordinate)
//     Cy      Coefficients of Chebyshev polyomial (y-coordinate)
//     Cz      Coefficients of Chebyshev polyomial (z-coordinate)
//
// Last modified:   2018/01/27   M. Mahooti
// 
//--------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/GHAmatrix.h"
/** @file Cheb3D.c
 *  @brief A code driver.
 *
 *  Chebyshev approximation of 3-dimensional vectors
 *
 *  @author japerego
 *  @bug No known bugs.
 */
double * Cheb3D(double t,double N,double  Ta, double Tb, double *Cx, double *Cy,double *Cz){

    double * ChebApp;
    ChebApp=vector(3);
    // Check validity
if( (t<Ta) || (Tb<t) ){
    printf("ERROR: Time out of range in Cheb3D::Value \n");
}
// Clenshaw algorithm
double tau = (2*t-Ta-Tb)/(Tb-Ta);  

double * f1 = vector(3);
double * f2 = vector(3);
double * old_f1=vector(3);

// printf("dentro cx \n");
//     printVector(Cx,3);

//     printf("dentro cy \n");
//     printVector(Cy,3);

//     printf("dentro cz \n");
//     printVector(Cz,3);

for (int i=2;i>0;--i){
    for (int j= 0; j < 3; ++j)
    {
        //Iteraciones para cambiar los valores que corresponderian a la parte de las iteraciones que no se realizan en Matlab
        old_f1[j]= f1[j];
        f1[j] = 2*tau*f1[j]-f2[j];
        f2[j] = old_f1[j];
        

    }
    //Le suma la correspondiente del vector corresponde a la ultima parte de --> f1 = 2*tau*f1-f2+  [Cx(i),Cy(i),Cz(i)];
    f1[0]+=Cx[i-1];
    f1[1]+=Cy[i-1];
    f1[2]+=Cz[i-1];
    //printVector(f1,3);

}
    // printf("dentro f1 \n");
    // printVector(f1,3);


    for (int j=0;j<3;++j){
        ChebApp[j] = tau*f1[j]-f2[j];
    }
    // printf("dentro f1 \n");
    // printVector(f1,3);

    freeVector(f1,3);
    freeVector(f2,3);
    freeVector(old_f1,3);


    ChebApp[0] += Cx[0];
    ChebApp[1] += Cy[0];
    ChebApp[2] += Cz[0];
    
    return ChebApp;
}

