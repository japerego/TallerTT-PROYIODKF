#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"

//Asumiremos que siempre sera para matrices nxn
/** @file TimeUpdate.c
 *  @brief A code driver.
 *
 *  
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double ** TimeUpdate(double ** P,double ** Phi, double ** Qdt,int n){
    /*
if (nargin == 2)
    Qdt = 0.0;
end
*/
//---------------ARREGLADO---------------
//Fallaba suma de matrices
// P = Phi*P*Phi' + Qdt;
// double **mult = array(n,n);
// mult=prod(prod(Phi,n,n,P,n,n),n,n,trasp(Phi,n),n,n);
// printArray(mult,n,n);

double **ret = array(n,n);
ret=sumaMatrices(prod(prod(Phi,n,n,P,n,n),n,n,trasp(Phi,n),n,n),n,n,Qdt,n,n);

//printf("RET DENTRO \n");
//printArray(ret,n,n);
return ret;




}




/*
function [P] = TimeUpdate(P, Phi, Qdt)

if (nargin == 2)
    Qdt = 0.0;
end

P = Phi*P*Phi' + Qdt; 

*/
