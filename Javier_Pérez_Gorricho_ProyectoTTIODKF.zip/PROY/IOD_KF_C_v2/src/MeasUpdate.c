//INPUTS: vectores x,z,g,s matrices, G, P, K otros valores: n tamaños de las mat y vectores.
//OUTPUTS: Matrices de salida K y P y vector de salida x
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
/** @file MeasUpdate.c
 *  @brief A code driver.
 *
 *  Computes the gradient of the Earth's harmonic gravity field 
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
void * MeasUpdate(double * x, double * z, double * g, double *s, double **G, double **P,int  n, double **K)
{

int m = length(z);
double **Inv_W = array(m,m);

for (int i=0;i<m;++i){
	Inv_W[i][i] = s[i]*s[i];    // Inverse weight (measurement covariance)
}
    
    
// Kalman gain

K = prod(prod(P,3,3,trasp(G,3),3,3),3,3,inv(sum(Inv_W,3,3,prod(prod(G,3,3,P,3,3),3,3,trasp(G,3),3,3),3,3),3),3,3);

// State update
x = sumaVectores(x ,mat_x_vec(K,3,3,restaVectores(z,g,3),3),3);

// Covariance update
P = prod(sum(eye(n),3,3,mat_x_esc(prod(K,3,3,G,3,3),3,3,-1.0),3,3),3,3,P,3,3);

}
