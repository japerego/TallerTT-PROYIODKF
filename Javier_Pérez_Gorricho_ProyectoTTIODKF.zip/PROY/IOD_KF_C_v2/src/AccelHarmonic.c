//--------------------------------------------------------------------------
//
// AccelHarmonic.m
//
// Purpose:
//   Computes the acceleration due to the harmonic gravity field of the 
//   central body
//
// Inputs:
//   r           Satellite position vector in the inertial system
//   E           Transformation matrix to body-fixed system
//   n_max       Maximum degree
//   m_max       Maximum order (m_max<=n_max; m_max=0 for zonals, only)
//
// Output:
//   a           Acceleration (a=d^2r/dt^2)
//
// Last modified:   2015/08/12   M. Mahooti
// 
//--------------------------------------------------------------------------


/** @file AccelHarmonic.c
 *  @brief A code driver.
 *
 *  Computes the perturbational acceleration due to a point mass
 *
 *  @author japerego
 *  @bug No known bugs.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
//cambiar los puntos cuando cambiemos localizacion del archivo
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/Legendre.h"
#include "../include/globales.h"

double * AccelHarmonic (double * r, double **E, int nE, int n_max, int m_max){
	extern double **Cnm, **Snm;
	double r_ref,gm,d,latgc,lon,*r_bf,**pnm,**dpnm,b1,b2,b3,ax,ay,az,*a_bf,r2xy,*a;
	
	r_ref = 6378.1363e3;   // Earth's radius [m]; GGM03S
	gm    = 398600.4415e9; // [m^3/s^2]; GGM03S

	// printArray(E,3,3);
	// printVector(r,3);

	//error valor devuelto es 0
	r_bf=mat_x_vec(E,3,3,r,3);

	//printVector(r_bf,3);

	d = norma(r_bf,3); 
	latgc = asin(r_bf[2]/d);
	lon = atan2(r_bf[1],r_bf[0]);

	pnm=array(n_max+1,m_max+1);
	dpnm=array(n_max+1,m_max+1);

	
	
	Legendre(n_max,m_max,latgc,pnm,dpnm);
	//printArray(pnm,3,3);

	double dUdr = 0;
	double dUdlatgc = 0;
	double dUdlon = 0;
	double q3 = 0; double q2 = q3; double q1 = q2;
	// printf("CNM DENTRO 11 %5.15lf",Cnm[1][1]);

	//printf("%.17g \n",d);

	for (int n=0;n<=n_max;++n){
		b1 = (-gm/(d*d))*pow((r_ref/d),n)*(n+1);
		//printf("%5.15g \n",b1);
    	b2 =  (gm/d)*pow((r_ref/d),n);
		//printf("b2 %5.15lf",b2);
    	b3 =  (gm/d)*pow((r_ref/d),n);
		//printf("b3 %5.15lf",b3);
    	for (int m=0;m<=m_max;++m){
       		// q1 = q1 + pnm[n+1][m+1]*(Cnm[n+1][m+1]*cos(m*lon)+Snm[n+1][m+1]*sin(m*lon));
        	// q2 = q2 + dpnm[n+1][m+1]*(Cnm[n+1][m+1]*cos(m*lon)+Snm[n+1][m+1]*sin(m*lon));
        	// q3 = q3 + m*pnm[n+1][m+1]*(Snm[n+1][m+1]*cos(m*lon)-Cnm[n+1][m+1]*sin(m*lon));
			
			q1 = q1 + pnm[n][m]*(Cnm[n+1][m+1]*cos(m*lon)+Snm[n+1][m+1]*sin(m*lon));
			
        	q2 = q2 + dpnm[n][m]*(Cnm[n+1][m+1]*cos(m*lon)+Snm[n+1][m+1]*sin(m*lon));
        	q3 = q3 + m*pnm[n][m]*(Snm[n+1][m+1]*cos(m*lon)-Cnm[n+1][m+1]*sin(m*lon));
		}
    dUdr     = dUdr     + q1*b1;
    dUdlatgc = dUdlatgc + q2*b2;
    dUdlon   = dUdlon   + q3*b3;
    q3 = 0; q2 = q3; q1 = q2;
	}


	//printf("dudr %5.15lf \n",dUdr);
	//printf("dudr %5.15lf \n",dUdlatgc);
	//printf("dudr %5.15lf \n",dUdlon);

	//Mayor eficiencia si no utilizamos pow

	r2xy =r_bf[0]*r_bf[0]+ r_bf[1]*r_bf[1];

	// printf("dudr %5.15lf",r2xy);

	ax = (1/d*dUdr-r_bf[2]/((d*d)*sqrt(r2xy))*dUdlatgc)*r_bf[0]-(1/r2xy*dUdlon)*r_bf[1];
	ay = (1/d*dUdr-r_bf[2]/((d*d)*sqrt(r2xy))*dUdlatgc)*r_bf[1]+(1/r2xy*dUdlon)*r_bf[0];
	az =  1/d*dUdr*r_bf[2]+sqrt(r2xy)/(d*d)*dUdlatgc;

	// printf("ax %5.15lf",ax);
	// printf("ay %5.15lf",ay);
	// printf("az %5.15lf",az);

	//printf("dentro ax %5.15lf\n",ax);

	a_bf=vector(3);
	a_bf[0] = ax;
	a_bf[1]= ay;
	a_bf[2]= az;


	
	// printf("dentro a_bf \n");
    // printVector(a_bf,3);
    
    //printf("\n");

	// Inertial acceleration 
	a = mat_x_vec(trasp(E,nE),3,3,a_bf,3);
    //printf("%lf",a[0]);
	//printVector(a,3);

	freeArray(pnm,n_max+1,m_max+1);
	freeArray(dpnm,n_max+1,m_max+1);
	freeVector(a_bf,3);
	freeVector(r_bf,3);

	return a;
}
