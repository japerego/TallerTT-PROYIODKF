//--------------------------------------------------------------------------
//
// PrecMatrix.m
//
// Purpose:
//
//   Precession transformation of equatorial coordinates
//
// Input:
//   Mjd_1     Epoch given (Modified Julian Date TT)
//   MjD_2     Epoch to precess to (Modified Julian Date TT)
// 
// Output:
//   PrecMat   Precession transformation matrix
//
// Last modified:   2015/08/12   M. Mahooti
// 
//--------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/R_z.h"
#include "../include/R_y.h"
/** @file PrexMatrix.c
 *  @brief A code driver.
 *
 *  Precession transformation of equatorial coordinates
 * 
 *  @author japerego
 *  @bug No known bugs.
 */

double **PrecMatrix (double Mjd_1,double Mjd_2)
{
double zeta,z,theta;

double T  = (Mjd_1-MJD_J2000)/36525;
double dT = (Mjd_2-Mjd_1)/36525;


zeta  =  ( (2306.2181+(1.39656-0.000139*T)*T)+((0.30188-0.000344*T)+0.017998*dT)*dT )*dT/(Arcs);
z     =  zeta + ( (0.79280+0.000411*T)+0.000205*dT)*dT*dT/(Arcs);
theta =  ( (2004.3109-(0.85330+0.000217*T)*T)- ((0.42665+0.000217*T)+0.041833*dT)*dT )*dT/(Arcs);

// Precession matrix
double **PrecMat = prod(prod(R_z(-z),3,3, R_y(theta),3,3),3,3, R_z(-zeta),3,3);

return PrecMat;
}
