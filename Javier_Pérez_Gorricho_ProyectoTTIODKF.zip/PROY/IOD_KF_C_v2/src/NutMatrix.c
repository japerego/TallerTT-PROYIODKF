//--------------------------------------------------------------------------
//
// NutMatrix.m
//
// Purpose:
//   Transformation from mean to true equator and equinox
//
// Input:
//   Mjd_TT    Modified Julian Date (Terrestrial Time)
//
// Output:
//   NutMat    Nutation matrix
//
// Last modified:   2015/08/12   M. Mahooti
// 
//--------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include "../include/arrays.h"
#include "../include/iodkf.h"
#include "../include/R_z.h"
#include "../include/R_x.h"
#include "../include/MeanObliquity.h"
#include "../include/NutAngles.h"
/** @file NutMatrix.c
 *  @brief A code driver.
 *
 *  Transformation from mean to true equator and equinox
 * 
 *  @author japerego
 *  @bug No known bugs.
 */
double **NutMatrix (double Mjd_TT){
	// Mean obliquity of the ecliptic
	double epsi = MeanObliquity (Mjd_TT);
	
	double deps,dpsi;
	deps=0;
	dpsi=0;
	// Nutation in longitude and obliquity
	NutAngles(Mjd_TT,&dpsi,&deps);

	// Transformation from mean to true equator and equinox
	double **NutMat = prod(prod(R_x(-epsi-deps),3,3,R_z(-dpsi),3,3),3,3,R_x(+epsi),3,3);
	
	return NutMat;

}


